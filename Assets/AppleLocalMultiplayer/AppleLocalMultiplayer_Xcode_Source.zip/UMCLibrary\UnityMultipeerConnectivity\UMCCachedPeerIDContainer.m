/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <MultipeerConnectivity/MultipeerConnectivity.h>
#import "UMCCachedPeerIDContainer.h"

static const NSString* const kDefaultsPeerIdKey = @"UMCCachedPeerID";

@implementation UMCCachedPeerIDContainer {

}

+ (UMCCachedPeerIDContainer*) sharedInstance {
    static UMCCachedPeerIDContainer* staticInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        staticInstance = [[self alloc] init];
    });
    return staticInstance;
}

- (MCPeerID*) getPeerIDWithDisplayName:(NSString*)displayName {
    MCPeerID* peerID = [self loadPeerID];
    if (peerID == nil || ![displayName isEqualToString:peerID.displayName]) {
        peerID = [[MCPeerID alloc] initWithDisplayName:displayName];
        [self storePeerID:peerID];
    }

    return peerID;
}

- (MCPeerID*) loadPeerID {
    NSData* data = [[NSUserDefaults standardUserDefaults] dataForKey:(NSString*) kDefaultsPeerIdKey];
    if (data == nil)
        return nil;

    MCPeerID* peerID = [NSKeyedUnarchiver unarchiveObjectWithData:data];
    return peerID;
}

- (void) storePeerID:(MCPeerID*) peer {
    NSData* data = [NSKeyedArchiver archivedDataWithRootObject:peer];
    [[NSUserDefaults standardUserDefaults] setObject:data forKey:(NSString*) kDefaultsPeerIdKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

@end
