/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <Cocoa/Cocoa.h>
#import <Foundation/Foundation.h>
#import "MCBrowserViewControllerSurrogate.h"
#import "UMCMediatorFacade.h"

static NSString* const LOG_TAG = @"MCBrowserViewControllerSurrogate";

static NSString* const UMCPeerInviteButtonHiddenKey = @"inviteButtonHidden";
static NSString* const UMCPeerPeerIDKey = @"peerID";
static NSString* const UMCPeerStateKey = @"state";
static NSString* const UMCPeerStateStringKey = @"stateString";
static NSString* const UMCPeerIsAdvertisingKey = @"isAdvertising";
static NSString* const UMCPeerInviteStateKey = @"inviteState";

static NSString* const MCBrowserViewControllerNibName = @"MCBrowserViewController";
static NSString* const MCSessionPrivateDelegatePropertyName = @"privateDelegate";

typedef NS_ENUM(NSInteger, UMCPeerInviteState) {
    UMCPeerInviteStateNone,
    UMCPeerInviteStateStartedInvite,
    UMCPeerInviteStateInvited,
    UMCPeerInviteStateDeclined
};

#define FRAMEWORK_LOCALIZABLE_STRING(key) NSLocalizedStringFromTableInBundle(key, nil, _frameworkBundle, nil)

@interface MCBrowserViewControllerSurrogate () <MCNearbyServiceBrowserDelegate>
@end

@implementation MCBrowserViewControllerSurrogate {
    MCNearbyServiceBrowser* _nearbyServiceBrowser;
    MCSession* _session;
    NSBundle* _frameworkBundle;

    NSMutableSet<MCPeerID*>* _hiddenPeers;
}

- (instancetype)initWithBrowser:(MCNearbyServiceBrowser*)browser session:(MCSession*)session {
    self = [super init];
    if (self) {
        _minimumNumberOfPeers = kMCSessionMinimumNumberOfPeers;
        _maximumNumberOfPeers = kMCSessionMaximumNumberOfPeers;

        _nearbyServiceBrowser = browser;
        _session = session;

        _hiddenPeers = [NSMutableSet new];
    }

    return self;
}

- (void)loadView {
    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);

    // Load MultipeerConnectivity framework
    _frameworkBundle = nil;
    for (NSBundle* frameworkBundle in [NSBundle allFrameworks]) {
        if ([[frameworkBundle.bundlePath lastPathComponent] isEqualToString:@"MultipeerConnectivity.framework"]) {
            _frameworkBundle = frameworkBundle;
            break;
        }
    }
    
    // Load MCBrowserViewController nib
    NSArray* objects;
    [_frameworkBundle loadNibNamed:MCBrowserViewControllerNibName owner:self topLevelObjects:&objects];

    _peers = [[NSMutableArray alloc] init];

    // Set self as MCSession.privateDelegate in order to not interfere with regular MCSession.delegate
    // Note: private API
    [_session setValue:self forKey:MCSessionPrivateDelegatePropertyName];

    // Start discovering peers
    _nearbyServiceBrowser.delegate = self;
    [_nearbyServiceBrowser startBrowsingForPeers];

    // Initialize UI
    self.spinning = YES;
    [self updateInterface];

    // Add connected peers on timer, since for some reason
    // notifications like viewDidAppear are not called when running under Unity
    [NSTimer scheduledTimerWithTimeInterval:0.01
                                     target:self
                                   selector:@selector(addAlreadyConnectedPeersTimer:)
                                   userInfo:nil
                                    repeats:NO];
}

- (void) addAlreadyConnectedPeersTimer:(NSTimer*)timer {
    // Add peers that were already connected
    for (MCPeerID* connectedPeer in _session.connectedPeers) {
        NSMutableDictionary* connectedPeerData =
                [self getPeerData:connectedPeer
            withPeerDiscoveryInfo:nil
               andCreateIfMissing:YES
   andSkipShouldPresentNearbyPeer:YES];
        [self updatePeer:connectedPeerData withState:MCSessionStateConnected];
    }
}

- (void) dealloc {
    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    // Stop discovering peers when closed
    [_nearbyServiceBrowser stopBrowsingForPeers];

    // Note: private API
    if ([_session valueForKey:MCSessionPrivateDelegatePropertyName] == self) {
        [_session setValue:nil forKey:MCSessionPrivateDelegatePropertyName];
    }
}

- (void) updateInterface {
    // +1 for current device
    NSInteger peersInSession = [_session connectedPeers].count + 1;
    NSInteger maxLeftPeers = _maximumNumberOfPeers - peersInSession;
    NSInteger requiredPeers = _minimumNumberOfPeers - peersInSession;
    if (requiredPeers < 0) {
        requiredPeers = 0;
    }

    _doneButton.enabled = peersInSession >= _minimumNumberOfPeers;

    NSString* titleText;
    if (_minimumNumberOfPeers == _maximumNumberOfPeers) {
        if (requiredPeers == 0) {
            titleText = @"";
        } else if (requiredPeers == 1) {
            titleText = [NSString stringWithFormat:FRAMEWORK_LOCALIZABLE_STRING(@"Choose %lu invitee:"), requiredPeers];
        } else {
            titleText = [NSString stringWithFormat:FRAMEWORK_LOCALIZABLE_STRING(@"Choose %lu invitees:"), requiredPeers];
        }
    } else {
        if (requiredPeers == 0) {
            if (maxLeftPeers == 0) {
                titleText = @"";
            } else if (maxLeftPeers == 1) {
                titleText = [NSString stringWithFormat:FRAMEWORK_LOCALIZABLE_STRING(@"Choose up to %lu more invitee:"), maxLeftPeers];
            } else {
                titleText = [NSString stringWithFormat:FRAMEWORK_LOCALIZABLE_STRING(@"Choose up to %lu more invitees:"), maxLeftPeers];
            }
        } else {
            titleText = [NSString stringWithFormat:FRAMEWORK_LOCALIZABLE_STRING(@"Choose %lu to %lu invitees:"), requiredPeers, maxLeftPeers];
        }
    }

    self.sectionTitle = titleText;
}

- (NSMutableDictionary*)getPeerData:(MCPeerID*)peerID
              withPeerDiscoveryInfo:(nullable NSDictionary<NSString*, NSString*>*)peerDiscoveryInfo
                 andCreateIfMissing:(BOOL)createIfMissing
     andSkipShouldPresentNearbyPeer:(BOOL)skipShouldPresentNearbyPeer {
    NSMutableDictionary* peerData = [self getExistingPeerData:peerID];
    if (peerData != nil)
        return peerData;

    if (!createIfMissing)
        return nil;

    // We might have just added the peer as already connected
    peerData = [self getExistingPeerData:peerID];
    if (peerData != nil)
        return peerData;

    if ([_hiddenPeers containsObject:peerID])
        return nil;

    if (!skipShouldPresentNearbyPeer) {
        BOOL shouldShow = YES;
        if (_delegate != nil) {
            shouldShow = [_delegate browserViewController:self
                                  shouldPresentNearbyPeer:peerID
                                        withDiscoveryInfo:peerDiscoveryInfo];
        }

        if (!shouldShow) {
            [_hiddenPeers addObject:peerID];
            return nil;
        }
    }
    
    // New peer
    peerData = [NSMutableDictionary new];
    peerData[UMCPeerPeerIDKey] = peerID;
    peerData[UMCPeerIsAdvertisingKey] = @NO;
    peerData[UMCPeerInviteStateKey] = @(UMCPeerInviteStateNone);
    [self updatePeer:peerData withState:MCSessionStateNotConnected];
    [_peersArrayController addObject:peerData];
    
    return peerData;
}

- (NSMutableDictionary*) getExistingPeerData:(MCPeerID*)peerID {
    for (NSMutableDictionary* peerData in _peers) {
        if ([((MCPeerID*)peerData[UMCPeerPeerIDKey]) hash] == peerID.hash)
            return peerData;
    }

    return nil;
}

- (void) updatePeer:(NSMutableDictionary*)peerData withState:(MCSessionState)peerState {
    peerData[UMCPeerStateKey] = @(peerState);
    UMCPeerInviteState inviteState = (UMCPeerInviteState) [peerData[UMCPeerInviteStateKey] integerValue];

    if (inviteState == UMCPeerInviteStateInvited) {
        if (peerState == MCSessionStateNotConnected) {
            inviteState = UMCPeerInviteStateDeclined;
        } else {
            inviteState = UMCPeerInviteStateNone;
        }
        
        peerData[UMCPeerInviteStateKey] = @(inviteState);
    }

    switch (inviteState) {
        case UMCPeerInviteStateNone:
            peerData[UMCPeerStateStringKey] = [self peerStateToPeerStateString:peerState];
            peerData[UMCPeerInviteButtonHiddenKey] = peerState != MCSessionStateNotConnected ? @YES : @NO;
            break;
        case UMCPeerInviteStateStartedInvite:
        case UMCPeerInviteStateInvited:
            peerData[UMCPeerStateStringKey] = FRAMEWORK_LOCALIZABLE_STRING(@"Inviting");
            peerData[UMCPeerInviteButtonHiddenKey] = @YES;
            break;
        case UMCPeerInviteStateDeclined:
            peerData[UMCPeerStateStringKey] = FRAMEWORK_LOCALIZABLE_STRING(@"Declined");
            peerData[UMCPeerInviteButtonHiddenKey] = @YES;
            break;
    }

    [self updateInterface];
}

- (NSString*) peerStateToPeerStateString:(MCSessionState)peerState {
    switch (peerState) {
        case MCSessionStateNotConnected: return FRAMEWORK_LOCALIZABLE_STRING(@"Not connected");
        case MCSessionStateConnecting: return FRAMEWORK_LOCALIZABLE_STRING(@"Connecting");
        case MCSessionStateConnected: return FRAMEWORK_LOCALIZABLE_STRING(@"Connected");
        default: return @"Unknown state";
    }
}

#pragma mark - MCNearbyServiceBrowserDelegate

// Found a nearby advertising peer.
- (void)        browser:(MCNearbyServiceBrowser*)browser
              foundPeer:(MCPeerID*)peerID
      withDiscoveryInfo:(nullable NSDictionary<NSString*, NSString*>*)info {
    [self getPeerData:peerID withPeerDiscoveryInfo:info andCreateIfMissing:YES andSkipShouldPresentNearbyPeer:NO];
}

// A nearby peer has stopped advertising.
- (void)browser:(MCNearbyServiceBrowser*)browser lostPeer:(MCPeerID*)peerID {
    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    NSMutableDictionary* peerData =
            [self  getPeerData:peerID
         withPeerDiscoveryInfo:nil
            andCreateIfMissing:NO
andSkipShouldPresentNearbyPeer:NO];
    if (peerData != nil) {
        [_peersArrayController removeObject:peerData];
        [self updateInterface];
    }

    [_hiddenPeers removeObject:peerID];
}

#pragma mark - Bound methods

- (IBAction)doneTapped:(id)sender {
    [_delegate browserViewControllerDidFinish:self];
}

- (IBAction)cancelTapped:(id)sender {
    [_delegate browserViewControllerWasCancelled:self];
}

- (IBAction)invitePeerClicked:(id)sender {
    UMC_LOG([sender description]);
    NSMutableDictionary* peerData = [((NSTableCellView*)[((NSControl*) sender) superview]) objectValue];
    peerData[UMCPeerInviteStateKey] = @(UMCPeerInviteStateStartedInvite);
    [self updatePeer:peerData withState:(MCSessionState) [peerData[UMCPeerStateKey] integerValue]];
    peerData[UMCPeerInviteStateKey] = @(UMCPeerInviteStateInvited);
    [_nearbyServiceBrowser invitePeer:peerData[UMCPeerPeerIDKey] toSession:_session withContext:nil timeout:30.0];
}

#pragma mark - MCSession.privateDelegate

- (void)session:(MCSession*)session didFinishReceivingResourceWithName:(NSString*)resourceName fromPeer:(MCPeerID*)peerID atURL:(NSURL*)localURL withError:(nullable NSError*)error propagate:(BOOL*)propagate {
    // Ignore
}
- (void)session:(MCSession*)session didReceiveData:(NSData*)data fromPeer:(MCPeerID*)peerID propagate:(BOOL*)propagate{
    // Ignore
}
- (void)session:(MCSession*)session didReceiveStream:(NSInputStream*)stream withName:(NSString*)streamName fromPeer:(MCPeerID*)peerID propagate:(BOOL*)propagate {
    // Ignore
}
- (void)session:(MCSession*)session didStartReceivingResourceWithName:(NSString*)resourceName fromPeer:(MCPeerID*)peerID withProgress:(NSProgress*)progress propagate:(BOOL*)propagate {
    // Ignore
}
- (void)session:(MCSession*)session peer:(MCPeerID*)peerID didChangeState:(MCSessionState)state propagate:(BOOL*)propagate {
    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    NSMutableDictionary* peerData =
            [self  getPeerData:peerID
         withPeerDiscoveryInfo:nil
            andCreateIfMissing:YES
andSkipShouldPresentNearbyPeer:NO];

    [self updatePeer:peerData withState:state];
}

@end


