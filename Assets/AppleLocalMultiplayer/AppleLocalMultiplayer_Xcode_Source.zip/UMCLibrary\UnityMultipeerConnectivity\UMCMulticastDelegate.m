/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import "UMCMulticastDelegate.h"


@implementation UMCMulticastDelegate {
    NSMutableArray<id>* _listeners;
}

- (instancetype) init {
    if (self = [super init]) {
        _listeners = [NSMutableArray<id> new];
    }

    return self;
}

- (void) addListener:(id)listener {
    if ([_listeners containsObject:listener])
        return;

    [_listeners addObject:listener];
}

- (void) removeListener:(id)listener {
    [_listeners removeObject:listener];
}

- (void) invokeWithBlock:(void (^)(id))block {
    for (unsigned int i = 0; i < _listeners.count; ++i) {
        id delegate = _listeners[i];
        block(delegate);
    }
}

@end