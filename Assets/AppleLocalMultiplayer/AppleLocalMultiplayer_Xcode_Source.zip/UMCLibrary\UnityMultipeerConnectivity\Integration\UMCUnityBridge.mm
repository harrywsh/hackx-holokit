/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import "UMCCommon.h"
#import "UMCMediatorFacade.h"
#import "UMCUnityBridgeNoARC.h"
#import "UMCUnityEvents.h"

#pragma clang diagnostic push
#pragma ide diagnostic ignored "OCUnusedGlobalDeclarationInspection"

static NSString* const LOG_TAG = @"Exports";

#define NSERROR_RETAIN_ON_FAIL()  { \
        if (!success) { UMC_NSObject_retain(error); *errorOut = error; } \
}

#ifdef __cplusplus
extern "C" {
#endif

#if !TARGET_OS_OSX
extern UIViewController* UnityGetGLViewController();
UIViewController* UMC_GetViewController() {
    return UnityGetGLViewController();
}
#elif TARGET_OS_OSX
NSWindow* UMC_GetMainWindow() {
    NSWindow* mainWindow = [[NSApplication sharedApplication] mainWindow];
    if (mainWindow == nil) {
        NSArray<NSWindow*>* windows = [[NSApplication sharedApplication] windows];
        for (NSWindow* window in windows) {
            if (window.isVisible) {
                mainWindow = window;
                break;
            }
        }
    }
    UMC_LOG_VERBOSE([NSString stringWithFormat:@"Main window: %@", mainWindow.description]);
    return mainWindow;
}
#endif

void UMC_UMCUnityEvents_SetEventListener(UMCUnityEventHandlerFunc eventHandlerFunc) {
    [UMCUnityEvents sharedInstance].eventHandlerFunc = eventHandlerFunc;
}

#pragma mark - UMCMediatorFacade

bool UMC_UMCMediatorFacade_SetDstHostAndDstPort(const char* dstHost, uint16_t dstPort, NSError* __unsafe_unretained* errorOut) {
    NSString* dstHostString = [NSString stringWithUTF8String:dstHost];
    NSError* __autoreleasing error = nil;
    bool success = [[UMCMediatorFacade sharedInstance] setDstHost:dstHostString andDstPort:dstPort error:&error];
    NSERROR_RETAIN_ON_FAIL();
    return success;
}

bool UMC_UMCMediatorFacade_SetServiceType(const char* serviceType, NSError* __unsafe_unretained* errorOut) {
    NSString* serviceTypeString = [NSString stringWithUTF8String:serviceType];
    NSError* __autoreleasing error = nil;
    bool success = [[UMCMediatorFacade sharedInstance] setServiceType:serviceTypeString error:&error];
    NSERROR_RETAIN_ON_FAIL();
    return success;
}

bool UMC_UMCMediatorFacade_SetDisplayName(const char* displayName, NSError* __unsafe_unretained* errorOut) {
    NSString* displayNameString = [NSString stringWithUTF8String:displayName];
    NSError* __autoreleasing error = nil;
    bool success = [[UMCMediatorFacade sharedInstance] setDisplayName:displayNameString error:&error];
    NSERROR_RETAIN_ON_FAIL();
    return success;
}

#if !TARGET_OS_OSX
bool UMC_UMCMediatorFacade_SetViewController(UIViewController* viewController, NSError* __unsafe_unretained* errorOut) {
    NSError* __autoreleasing error = nil;
    bool success = [[UMCMediatorFacade sharedInstance] setViewController:viewController error:&error];
    NSERROR_RETAIN_ON_FAIL();
    return success;
}
#elif TARGET_OS_OSX
bool UMC_UMCMediatorFacade_SetMainWindow(NSWindow* mainWindow, NSError* __unsafe_unretained* errorOut) {
    NSError* __autoreleasing error = nil;
    bool success = [[UMCMediatorFacade sharedInstance] setMainWindow:mainWindow error:&error];
    NSERROR_RETAIN_ON_FAIL();
    return success;
}
#endif

bool UMC_UMCMediatorFacade_StartSession(NSError* __unsafe_unretained* errorOut) {
    NSError* __autoreleasing error = nil;
    bool success = [[UMCMediatorFacade sharedInstance] startSession:&error];
    NSERROR_RETAIN_ON_FAIL();
    return success;
}

bool UMC_UMCMediatorFacade_DisconnectFromSession(NSError* __unsafe_unretained* errorOut) {
    NSError* __autoreleasing error = nil;
    bool success = [[UMCMediatorFacade sharedInstance] disconnectFromSession:&error];
    NSERROR_RETAIN_ON_FAIL();
    return success;
}

bool UMC_UMCMediatorFacade_IsSessionActive() {
    return [UMCMediatorFacade sharedInstance].isSessionActive;
}

bool UMC_UMCMediatorFacade_InvitePeerToSession(MCPeerID* peerID, double timeout, NSError* __unsafe_unretained* errorOut) {
    NSError* __autoreleasing error = nil;
    bool success = [[UMCMediatorFacade sharedInstance] invitePeerToSession:peerID withTimeout:timeout error:&error];
    NSERROR_RETAIN_ON_FAIL();
    return success;
}

#if !(TARGET_OS_OSX || TARGET_OS_TV)

bool UMC_UMCMediatorFacade_IsBluetoothEnabled() {
    return [UMCMediatorFacade sharedInstance].isBluetoothEnabled;
}

bool UMC_UMCMediatorFacade_OpenBluetoothEnablePrompt(NSError* __unsafe_unretained* errorOut) {
    NSError* __autoreleasing error = nil;
    bool success = [[UMCMediatorFacade sharedInstance] openBluetoothEnablePrompt:&error];
    NSERROR_RETAIN_ON_FAIL();
    return success;
}

#endif

#pragma mark - Advertiser

bool UMC_UMCMediatorFacade_StartAdvertiserWithDiscoveryInfo(
        UMC_StringStringKeyValuePair* discoveryInfoPairArray,
        int32_t discoveryInfoPairArrayCount,
        NSError* __unsafe_unretained* errorOut) {
    NSDictionary* discoveryInfo = UMC_ConvertStringStringPairsToDictionary(discoveryInfoPairArray, discoveryInfoPairArrayCount);
    NSError* __autoreleasing error = nil;
    bool success = [[UMCMediatorFacade sharedInstance] startAdvertiserWithDiscoveryInfo:discoveryInfo error:&error];
    NSERROR_RETAIN_ON_FAIL();
    return success;
}

bool UMC_UMCMediatorFacade_StopAdvertiser(NSError* __unsafe_unretained* errorOut) {
    NSError* __autoreleasing error = nil;
    bool success = [[UMCMediatorFacade sharedInstance] stopAdvertiser:&error];
    NSERROR_RETAIN_ON_FAIL();
    return success;
}

bool UMC_UMCMediatorFacade_IsAdvertiserAdvertising() {
    return [[UMCMediatorFacade sharedInstance] isAdvertiserAdvertising];
}

#pragma mark - Advertiser assistant

bool UMC_UMCMediatorFacade_StartAdvertiserAssistantWithDiscoveryInfo(
        UMC_StringStringKeyValuePair* discoveryInfoPairArray,
        int32_t discoveryInfoPairArrayCount,
        NSError* __unsafe_unretained* errorOut) {
    NSDictionary* discoveryInfo = UMC_ConvertStringStringPairsToDictionary(discoveryInfoPairArray, discoveryInfoPairArrayCount);
    NSError* __autoreleasing error = nil;
    bool success = [[UMCMediatorFacade sharedInstance] startAdvertiserAssistantWithDiscoveryInfo:discoveryInfo error:&error];
    NSERROR_RETAIN_ON_FAIL();
    return success;
}

bool UMC_UMCMediatorFacade_StopAdvertiserAssistant(NSError* __unsafe_unretained* errorOut) {
    NSError* __autoreleasing error = nil;
    bool success = [[UMCMediatorFacade sharedInstance] stopAdvertiserAssistant:&error];
    NSERROR_RETAIN_ON_FAIL();
    return success;
}

bool UMC_UMCMediatorFacade_IsAdvertiserAssistantAdvertising() {
    return [[UMCMediatorFacade sharedInstance] isAdvertiserAssistantAdvertising];
}

#pragma mark - Custom peer discovery

bool UMC_UMCMediatorFacade_StartPeerDiscovery(NSError* __unsafe_unretained* errorOut) {
    NSError* __autoreleasing error = nil;
    bool success = [[UMCMediatorFacade sharedInstance] startPeerDiscovery:&error];
    NSERROR_RETAIN_ON_FAIL();
    return success;
}

bool UMC_UMCMediatorFacade_StopPeerDiscovery(NSError* __unsafe_unretained* errorOut) {
    NSError* __autoreleasing error = nil;
    bool success = [[UMCMediatorFacade sharedInstance] stopPeerDiscovery:&error];
    NSERROR_RETAIN_ON_FAIL();
    return success;
}

#pragma mark - Peer discovery UI

bool UMC_UMCMediatorFacade_OpenPeerBrowser(uint32_t minimumNumberOfPeers, uint32_t maximumNumberOfPeers, NSError* __unsafe_unretained* errorOut) {
    NSError* __autoreleasing error = nil;
    bool success = [[UMCMediatorFacade sharedInstance] openPeerBrowserWithMinimumNumberOfPeers:minimumNumberOfPeers
                                                                       andMaximumNumberOfPeers:maximumNumberOfPeers
                                                                                         error:&error];
    NSERROR_RETAIN_ON_FAIL();
    return success;
}

bool UMC_UMCMediatorFacade_ClosePeerBrowser(NSError* __unsafe_unretained* errorOut) {
    NSError* __autoreleasing error = nil;
    bool success = [[UMCMediatorFacade sharedInstance] closePeerBrowser:&error];
    NSERROR_RETAIN_ON_FAIL();
    return success;
}

#pragma mark - Other methods

bool UMC_UMCMediatorFacade_GetConnectedPeers(
        int32_t maxConnectedPeersCount,
        MCPeerID* __unsafe_unretained** connectedPeersArrayOut,
        int32_t* connectedPeersCountOut,
        NSError* __unsafe_unretained* errorOut) {
    *connectedPeersArrayOut = NULL;
    *connectedPeersCountOut = -1;
    NSError* __autoreleasing error = nil;
    NSArray<MCPeerID*>* connectedPeersObjC = [[UMCMediatorFacade sharedInstance] getConnectedPeers:&error];
    bool success = connectedPeersObjC != nil;
    if (!success) {
        NSERROR_RETAIN_ON_FAIL();
        return false;
    }

    *connectedPeersCountOut = (int32_t) connectedPeersObjC.count;
    if (maxConnectedPeersCount >= 0 && *connectedPeersCountOut > maxConnectedPeersCount) {
        *connectedPeersCountOut = maxConnectedPeersCount;
    }

    if (*connectedPeersCountOut == 0)
        return true;

    *connectedPeersArrayOut = UMC_MALLOC_ARRAY(*connectedPeersCountOut, MCPeerID* __unsafe_unretained);
    success = *connectedPeersArrayOut != NULL;
    if (!success) {
        error = UMC_NSERROR(UMCErrorFatal, @"Out of memory");
        NSERROR_RETAIN_ON_FAIL();

        return false;
    }

    for (unsigned int i = 0; i < *connectedPeersCountOut; ++i) {
        MCPeerID* peer = connectedPeersObjC[i];
        // Retain the object until it is processed by managed side
        UMC_NSObject_retain(peer);
        (*connectedPeersArrayOut)[i] = peer;
    }

    return true;
}


bool UMC_UMCMediatorFacade_GetConnectedPeersCount(int32_t* connectedPeersCountOut, NSError* __unsafe_unretained* errorOut) {
    *connectedPeersCountOut = -1;
    NSError* __autoreleasing error = nil;
    NSArray<MCPeerID*>* connectedPeersObjC = [[UMCMediatorFacade sharedInstance] getConnectedPeers:&error];
    bool success = connectedPeersObjC != nil;
    if (!success) {
        NSERROR_RETAIN_ON_FAIL();
        return false;
    }

    *connectedPeersCountOut = (int32_t) connectedPeersObjC.count;
    return true;
}

void UMC_UMCMediatorFacade_SetLogForwarding(bool isEnabled) {
    [UMCMediatorFacade sharedInstance].logForwarding = isEnabled;
}

#pragma mark - UMCLog

bool UMC_UMCLog_GetIsVerboseLog() {
    return (bool) UMCLog.isVerbose;
}

void UMC_UMCLog_SetIsVerboseLog(bool isVerbose) {
    UMCLog.isVerbose = isVerbose;
}

#pragma mark - NSError

int32_t UMC_NSError_code(NSError* error) {
    return (int32_t) [error code];
}

const char* UMC_NSError_localizedDescription(NSError* error) {
    return strdup([error.localizedDescription UTF8String]);
}

#pragma mark - MCPeerID

const char* UMC_MCPeerID_displayName(MCPeerID* peerID) {
    return strdup([peerID.displayName UTF8String]);
}

#pragma mark - NSObject

uint64_t UMC_NSObject_hash(NSObject* obj) {
    return (uint64_t) [obj hash];
}

BOOL UMC_NSObject_isEquals(NSObject* objA, NSObject* objB) {
    return [objA isEqual:objB];
}

#pragma mark - Native functions

void UMC_free(void* ptr) {
    if (ptr == NULL)
        return;

    free(ptr);
}

#pragma mark - Misc

void UMC_FreeEventData(UMCUnityEventType eventType, void* eventDataPtr) {
    switch (eventType) {
        case UMCUnityEventTypeSessionStarted: break;
        case UMCUnityEventTypeSessionDisconnected: break;
        case UMCUnityEventTypeSessionPeerStateChanged: break;
        case UMCUnityEventTypeAdvertiserInvitationReceived: break;
        case UMCUnityEventTypeAdvertiserStartFailed:
        {
            struct UMC_ErrorStringEventData* eventData = (UMC_ErrorStringEventData*) eventDataPtr;
            free((void*) eventData->error);
            break;
        }
        case UMCUnityEventTypeAdvertiserAssistantInvitationDismissed: break;
        case UMCUnityEventTypeAdvertiserAssistantInvitationPresenting: break;
        case UMCUnityEventTypeNearbyServiceBrowserPeerFound:
        {
            struct UMC_PeerFoundEventData* eventData = (UMC_PeerFoundEventData*) eventDataPtr;
            UMC_FreeStringStringKeyValuePairs(eventData->discoveryInfoPairArray, eventData->discoveryInfoArrayPairCount);
            break;
        }
        case UMCUnityEventTypeNearbyServiceBrowserPeerLost: break;
        case UMCUnityEventTypeNearbyServiceBrowserStartFailed:
        {
            struct UMC_ErrorStringEventData* eventData = (UMC_ErrorStringEventData*) eventDataPtr;
            free((void*) eventData->error);
            break;
        }
        case UMCUnityEventTypeBrowserViewControllerCancelled: break;
        case UMCUnityEventTypeBrowserViewControllerFinished: break;
        case UMCUnityEventTypeBrowserViewControllerNearbyPeerPresenting:
        {
            UMC_BrowserViewControllerNearbyPeerPresentingEventData* eventData = (UMC_BrowserViewControllerNearbyPeerPresentingEventData*) eventDataPtr;
            UMC_FreeStringStringKeyValuePairs(eventData->discoveryInfoPairArray, eventData->discoveryInfoArrayPairCount);
            free(eventData->result);
            break;
        }
        case UMCUnityEventTypeLog: {
            struct UMC_LogEventData* eventData = (UMC_LogEventData*) eventDataPtr;
            free((void*) eventData->text);
            break;
        }
    }

    if (eventDataPtr != NULL) {
        free(eventDataPtr);
    }
}

void UMC_AdvertiserInvitationHandlerBlock_Invoke(UMCAdvertiserInvitationHandlerBlock block, bool accept, MCSession* session) {
    if (block == nil)
        return;

    if (session == nil && [UMCMediatorFacade sharedInstance].isSessionActive) {
        session = [UMCMediatorFacade sharedInstance].sessionController.sessionContainer.session;
    }

    if (session == nil) {
        UMC_LOG_ERROR(@"No active session found");
        return;
    }

    block(accept, session);
}

#ifdef __cplusplus
}
#endif
#pragma clang diagnostic pop
