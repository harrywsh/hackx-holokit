/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import "UMCCommon.h"
#import "UMCUdpNetworkingSessionController.h"
#import "UMCSocketsUtility.h"
#import "UMCUdpSocketConnectionDelegate.h"
#import "UMCSessionController.Protected.h"
#import "UMCUdpPeerState.h"

static NSString* const LOG_TAG = @"UdpNetworkingSession";

@interface UMCUdpNetworkingSessionController () <UMCSessionContainerDelegate, UMCUdpSocketConnectionDelegate>
@end

@implementation UMCUdpNetworkingSessionController {
    NSString* _dstHost;
    unsigned short _dstHostPort;
    NSMutableDictionary<MCPeerID*, NSDictionary<NSString*, NSString*>*>* _foundPeers;
    MCPeerID* _serverPeer;
    BOOL _isServerPeerConnected;
    dispatch_queue_t _delegateQueue;
}

- (instancetype) initWithDisplayName:(NSString*)displayName
                      andServiceType:(NSString*)serviceType
                          andDstHost:(NSString*)dstHost
                      andDstHostPort:(unsigned short)dstHostPort {
    if (self = [super initWithDisplayName:displayName andServiceType:serviceType]) {
        _dstHost = dstHost;
        _dstHostPort = dstHostPort;
        _foundPeers = [NSMutableDictionary new];
        _delegateQueue = dispatch_queue_create("UdpDelegateQueue", DISPATCH_QUEUE_SERIAL);
    }
    
    return self;
}

- (void) dealloc {
    for (UMCUdpPeerState* peerState in _peers) {
        if (peerState.udpSocketConnection != nil) {
            [peerState.udpSocketConnection stopConnection];
        }
    }

    [_peers removeAllObjects];
}

- (UMCPeerState*) createPeerStateForPeer:(MCPeerID*)peerID {
    return [[UMCUdpPeerState alloc] initWithPeer:peerID];
}

- (void) peerBrowserFoundPeer:(MCPeerID*)peerID withDiscoveryInfo:(NSDictionary<NSString*, NSString*>*)info {
    _foundPeers[peerID] = info == nil ? [NSDictionary new] : info;
}

- (void) peerBrowserLostPeer:(MCPeerID*)peerID {
    [_foundPeers removeObjectForKey:peerID];
}

#pragma mark - UMCSessionContainerDelegate

- (void) processPeerStateChange:(MCPeerID*)peerID newPeerState:(UMCPeerState*)peerState {
    //[super processPeerStateChange:peerID newPeerState:peerState];

    UMCUdpPeerState* udpPeerState = (UMCUdpPeerState*) peerState;

    switch (peerState.state) {
        case MCSessionStateNotConnected:
            if (udpPeerState.udpSocketConnection != nil) {
                [udpPeerState.udpSocketConnection stopConnection];
                udpPeerState.udpSocketConnection = nil;
            }
            
            [_peers removeObject:peerState];
            if (peerID == _serverPeer) {
                _isServerPeerConnected = false;
                UMC_LOG(@"Server peerID lost, disconnecting from session");
                [_sessionContainer.session disconnect];
            }
            break;
        case MCSessionStateConnecting:break;
        case MCSessionStateConnected:
            if (udpPeerState.udpSocketConnection != nil) {
                //[peerState.udpSocketConnection stopConnection];
            } else {
                NSDictionary<NSString*, NSString*>* discoveryInfo = _foundPeers[peerID];
                
                // If peer is at least found
                bool flag = false;
                if (discoveryInfo != nil) {
                    UMC_LOG([NSString stringWithFormat:@"Server peer connected: %@", peerID.displayName]);
                    _serverPeer = peerID;
                    flag = true;
                }
                
                if (!_isServerPeerConnected) {
                    int dstPort;
                    int srcPort;
                    
                    // When we are connecting to the server
                    if (peerID == _serverPeer) {
                        dstPort = 0;
                        srcPort = _dstHostPort;
                    } else {
                        // When we are the server, and a client connects
                        dstPort = _dstHostPort;
                        srcPort = 0;
                    }
                    
                    udpPeerState.udpSocketConnection =
                    [[UMCUdpSocketConnection alloc]
                     initWithDstHost:_dstHost
                             dstPort:dstPort
                             srcPort:srcPort
                       delegateQueue:_delegateQueue
                            delegate:self];
                    
                    [udpPeerState.udpSocketConnection startSocket];
                }
                if (flag) {
                    _isServerPeerConnected = true;
                }
            }
            break;
    }
}

- (void) session:(MCSession*)session didReceiveData:(NSData*)data fromPeer:(MCPeerID*)peerID {
    [super session:session didReceiveData:data fromPeer:peerID];

    UMCUdpPeerState* peerState = (UMCUdpPeerState*) [self getPeerStateByPeerID:peerID andCreateIfMissing:NO];
    if (peerState != nil) {
        [peerState.udpSocketConnection send:data withTimeout:10];
    }
}

#pragma mark - UMCUdpSocketConnectionDelegate

- (void) udpSocketRead:(UMCUdpSocketConnection*)socketConnection fromAddress:(NSData*)address withData:(NSData*)data {
    for (UMCUdpPeerState* peerState in _peers) {
        if (socketConnection != peerState.udpSocketConnection)
            continue;

        int srcPort = [UMCSocketsUtility portFromData:address];

        [peerState.udpSocketConnection setDstPort:srcPort];
        NSArray<MCPeerID*>* peersArray = @[peerState.peerID];
        NSError* error;
        [_sessionContainer.session sendData:data toPeers:peersArray withMode:MCSessionSendDataUnreliable error:&error];
        if (error != nil) {
            UMC_LOG_ERROR([NSString stringWithFormat:@"Error while sending to peer: %@", error]);
        }
    }
}

- (void) udpSocketFailure:(UMCUdpSocketConnection*)socketConnection {

}

@end
