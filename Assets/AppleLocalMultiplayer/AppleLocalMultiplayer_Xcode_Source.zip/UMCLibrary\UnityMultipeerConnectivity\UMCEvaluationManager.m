/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#if UMC_EVALUATION

#if TARGET_OS_OSX
  #import <AppKit/AppKit.h>
#else
#endif

#import "UMCCommon.h"
#import "UMCMediatorFacade.h"
#import "UMCEvaluationManager.h"

static NSString* const LOG_TAG = @"Evaluation";

static const NSUInteger kEvaluationTimeMinutes = 10;
static const NSUInteger kEvaluationTimeSeconds = kEvaluationTimeMinutes * 60;
//static const NSUInteger kEvaluationTimeSeconds = 10;

static NSString* const kAssetName = @"Local Multiplayer for iOS/tvOS/macOS";

static NSString* const kEvaluationMessageTitle =
        @"Local Multiplayer for iOS/tvOS/macOS Evaluation";
static NSString* const kEvaluationMessageMessage =
        @"Thank you for your interest in Local Multiplayer for iOS/tvOS/macOS! This is an evaluation version which will force close "
                "this application in 10 minutes. If you like this asset, please consider purchasing on Asset Store.";
static NSString* const kEvaluationMessageEditorMessage =
        @"Thank you for your interest in Local Multiplayer for iOS/tvOS/macOS! This is an evaluation version, applications built with it "
                "will close in 10 minutes. If you like this asset, please consider purchasing on Asset Store.";
static NSString* const kEvaluationMessageUrl = @"https://www.assetstore.unity3d.com/en/#!/content/88666";

@implementation UMCEvaluationManager {
    BOOL _isFirstCheckDone;
}

+ (UMCEvaluationManager*) sharedInstance {
    static UMCEvaluationManager* sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
    });
    return sharedInstance;
}

- (instancetype) init {
    self = [super init];
    if (self) {
        _isFirstCheckDone = NO;
    }
    
    return self;
}

- (void) checkEvaluation {
    if (_isFirstCheckDone)
        return;

    _isFirstCheckDone = YES;

#if TARGET_OS_OSX
  #if UMC_UNITY_EDITOR
    // Prevent using the Unity Editor build for macOS
    NSDictionary<NSString*, id>* mainBundleInfo = [[NSBundle mainBundle] infoDictionary];
    if (![((NSString*) mainBundleInfo[@"CFBundleExecutable"]) isEqualToString:@"Unity"] ||
        ![((NSString*) mainBundleInfo[@"CFBundleSignature"]) isEqualToString:@"UNED"]) {
        exit(EXIT_SUCCESS);
    }
  #endif
        
    NSAlert *alert = [[NSAlert alloc] init];
    [alert setMessageText:kEvaluationMessageTitle];
  #if UMC_UNITY_EDITOR
    [alert setInformativeText:kEvaluationMessageEditorMessage];
  #else
    [alert setInformativeText:kEvaluationMessageMessage];
  #endif
    [alert addButtonWithTitle:@"OK"];
    [alert addButtonWithTitle:@"Buy on Asset Store"];
    NSInteger result = [alert runModal];
    if (result == NSAlertSecondButtonReturn) {
        system([[NSString stringWithFormat:@"%@ %@", @"open", kEvaluationMessageUrl] UTF8String]);
    }

#if UMC_UNITY_EDITOR
    // No time bomb for Editor
    return;
#endif
#elif TARGET_OS_IOS
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kEvaluationMessageTitle
                                                    message:kEvaluationMessageMessage
                                                   delegate:self
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:@"Buy on Asset Store", nil];
    [alert show];
#elif TARGET_OS_TV
    UIAlertController* alert = [UIAlertController
          alertControllerWithTitle:kEvaluationMessageTitle
          message:kEvaluationMessageMessage
          preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* defaultAction = [UIAlertAction
                                    actionWithTitle:@"OK" style:UIAlertActionStyleCancel
                                    handler:^(UIAlertAction* action) {}];

    [alert addAction:defaultAction];
    // tvOS has no built-in browser?!
    /*
     UIAlertAction* buyAction = [UIAlertAction
     actionWithTitle:@"Buy on Asset store" style:UIAlertActionStyleDefault
     handler:^(UIAlertAction* action) {
     [[UIApplication sharedApplication] openURL:[[NSURL alloc] initWithString:kEvaluationMessageUrl] options:[NSDictionary new] completionHandler:nil];
     }];
     
     [alert addAction:buyAction];
     */
    
    UIViewController *topViewController = [[[[UIApplication sharedApplication] delegate] window] rootViewController];
    while (topViewController.presentedViewController) topViewController = topViewController.presentedViewController;

    [topViewController presentViewController:alert animated:YES completion:nil];
#endif

    [NSTimer scheduledTimerWithTimeInterval:kEvaluationTimeSeconds
                                     target:self
                                   selector:@selector(closeAppTimerHandler:)
                                   userInfo:nil
                                    repeats:NO];
}

- (void)closeAppTimerHandler:(NSTimer*)timer {
    exit(EXIT_SUCCESS);
}

#if TARGET_OS_IOS
- (void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 1) {
        [[UIApplication sharedApplication] openURL:[[NSURL alloc] initWithString:kEvaluationMessageUrl] options:[NSDictionary new] completionHandler:nil];
    }
}
#endif

@end

#endif
