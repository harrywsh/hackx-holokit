/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol UMCLogListenerDelegate;

#define UMC_LOG_VERBOSE_INTERNAL(...) do { if ([UMCLog isVerbose]) { __VA_ARGS__; } } while(false)

#define UMC_LOG(...) [UMCLog log:(__VA_ARGS__) withTitle:LOG_TAG]
#define UMC_LOG_PRETTY_FUNCTION ([NSString stringWithFormat:@"%s", __PRETTY_FUNCTION__])
#define UMC_LOG_VERBOSE(...) UMC_LOG_VERBOSE_INTERNAL(UMC_LOG(__VA_ARGS__))
#define UMC_LOG_WARNING(...) [UMCLog logWarning:(__VA_ARGS__) withTitle:LOG_TAG]
#define UMC_LOG_WARNING_VERBOSE(...) UMC_LOG_VERBOSE_INTERNAL(UMC_LOG_WARNING(__VA_ARGS__))
#define UMC_LOG_ERROR(...) [UMCLog logError:(__VA_ARGS__) withTitle:LOG_TAG]
#define UMC_LOG_ERROR_VERBOSE(...) UMC_LOG_VERBOSE_INTERNAL(UMC_LOG_ERROR(__VA_ARGS__))

@interface UMCLog : NSObject

@property (class, weak, nullable) id<UMCLogListenerDelegate> delegate;
@property (class, assign) BOOL isVerbose;

+ (void) log:(const NSString*)text;

+ (void) log:(const NSString*)text withTitle:(const NSString*)title;

+ (void) logWarning:(const NSString*)text;

+ (void) logWarning:(const NSString*)text withTitle:(const NSString*)title;

+ (void) logError:(const NSString*)text;

+ (void) logError:(const NSString*)text withTitle:(const NSString*)title;

+ (void) logStartupMessage;
@end

NS_ASSUME_NONNULL_END

typedef NS_ENUM(int32_t, UMCLogType) {
    UMCLogTypeLog,
    UMCLogTypeWarning,
    UMCLogTypeError
};