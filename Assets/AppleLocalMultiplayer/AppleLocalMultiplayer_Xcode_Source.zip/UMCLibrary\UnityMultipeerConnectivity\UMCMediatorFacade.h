/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <Foundation/Foundation.h>

#import "UMCCommon.h"
#import "UMCSessionContainer.h"
#import "UMCPeerDiscovery.h"
#import "UMCUdpNetworkingSessionController.h"
#import "UMCSessionController.h"

@interface UMCMediatorFacade : NSObject

@property (nonatomic, assign) BOOL logForwarding;
@property (readonly) UMCSessionController* sessionController;
@property (readonly) UMCPeerDiscovery* peerDiscovery;
@property (nonatomic) BOOL isSessionActive;
#if !(TARGET_OS_OSX || TARGET_OS_TV)
@property (readonly) BOOL isBluetoothEnabled;
#endif

+ (UMCMediatorFacade*) sharedInstance;

- (BOOL) setDstHost:(NSString*)dstHost andDstPort:(int)dstPort error:(NSError* __autoreleasing *)error;

- (BOOL) setServiceType:(NSString*)serviceType error:(NSError* __autoreleasing *)error;

- (BOOL) setDisplayName:(NSString*)displayName error:(NSError* __autoreleasing *)error;

#if !TARGET_OS_OSX
- (BOOL) setViewController:(UIViewController*)viewController error:(NSError* __autoreleasing *)error;
#elif TARGET_OS_OSX
- (BOOL) setMainWindow:(NSWindow*)mainWindow error:(NSError* __autoreleasing *)error;
#endif
- (BOOL) startSession:(NSError* __autoreleasing *)error;

- (BOOL) disconnectFromSession:(NSError* __autoreleasing *)error;

- (NSArray<MCPeerID*>*) getConnectedPeers:(NSError* __autoreleasing *)error;

#if !(TARGET_OS_OSX || TARGET_OS_TV)
- (BOOL) openBluetoothEnablePrompt:(NSError* __autoreleasing *)error;
#endif

#pragma mark - Advertiser

- (BOOL) startAdvertiserWithDiscoveryInfo:(NSDictionary<NSString*, NSString*>*) discoveryInfo
                                    error:(NSError* __autoreleasing *)error;

- (BOOL) stopAdvertiser:(NSError* __autoreleasing *)error;

- (BOOL) isAdvertiserAdvertising;

#pragma mark - Advertiser assistant

- (BOOL) startAdvertiserAssistantWithDiscoveryInfo:(NSDictionary<NSString*, NSString*>*) discoveryInfo
                                             error:(NSError* __autoreleasing *)error;

- (BOOL) stopAdvertiserAssistant:(NSError* __autoreleasing *)error;

- (BOOL) isAdvertiserAssistantAdvertising;

#pragma mark - Custom peer discovery

- (BOOL) startPeerDiscovery:(NSError* __autoreleasing *)error;

- (BOOL) stopPeerDiscovery:(NSError* __autoreleasing *)error;

- (BOOL) invitePeerToSession:(MCPeerID*)peerID withTimeout:(NSTimeInterval)timeout
                       error:(NSError* __autoreleasing *)error;

#pragma mark - Peer discovery UI

- (BOOL) openPeerBrowserWithMinimumNumberOfPeers:(NSUInteger)minimumNumberOfPeers
                         andMaximumNumberOfPeers:(NSUInteger)maximumNumberOfPeers
                                           error:(NSError* __autoreleasing *)error;

- (BOOL) closePeerBrowser:(NSError* __autoreleasing *)error;
@end
