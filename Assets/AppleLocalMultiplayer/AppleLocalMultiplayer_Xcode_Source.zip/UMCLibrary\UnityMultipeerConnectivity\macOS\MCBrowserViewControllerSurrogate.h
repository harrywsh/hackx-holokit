/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#if TARGET_OS_OSX

#import <Cocoa/Cocoa.h>
#import <MultipeerConnectivity/MultipeerConnectivity.h>

@protocol MCBrowserViewControllerSurrogateDelegate;

NS_ASSUME_NONNULL_BEGIN

@interface MCBrowserViewControllerSurrogate : NSViewController
// Create a browser view controller with a programmatic browser and a session.
- (instancetype)initWithBrowser:(MCNearbyServiceBrowser *)browser session:(MCSession *)session;

@property (weak, NS_NONATOMIC_IOSONLY, nullable) id<MCBrowserViewControllerSurrogateDelegate> delegate;

@property (readonly, NS_NONATOMIC_IOSONLY) MCNearbyServiceBrowser* browser;
@property (readonly, NS_NONATOMIC_IOSONLY) MCSession *session;
// The minimum number of peers the session should expect.
@property (assign, NS_NONATOMIC_IOSONLY) NSUInteger minimumNumberOfPeers;
// The maximum number of peers the session should expect.
@property (assign, NS_NONATOMIC_IOSONLY) NSUInteger maximumNumberOfPeers;

// Private

@property (copy) NSString* sectionTitle;
@property (assign) BOOL spinning;
@property (strong) NSMutableArray<NSMutableDictionary*>* peers;

@property (weak, nonatomic) IBOutlet NSButton* cancelButton;
@property (weak, nonatomic) IBOutlet NSButton* doneButton;
@property (weak, nonatomic) IBOutlet NSArrayController* peersArrayController;

@end

@protocol MCBrowserViewControllerSurrogateDelegate <NSObject>
// Notifies the delegate, when the user taps the done button.
- (void)browserViewControllerDidFinish:(MCBrowserViewControllerSurrogate *)browserViewController;

// Notifies delegate that the user taps the cancel button.
- (void)browserViewControllerWasCancelled:(MCBrowserViewControllerSurrogate *)browserViewController;

@optional
// Notifies delegate that a peer was found; discoveryInfo can be used to
// determine whether the peer should be presented to the user, and the
// delegate should return a YES if the peer should be presented; this method
// is optional, if not implemented every nearby peer will be presented to
// the user.
- (BOOL)browserViewController:(MCBrowserViewControllerSurrogate *)browserViewController
      shouldPresentNearbyPeer:(MCPeerID *)peerID
            withDiscoveryInfo:(nullable NSDictionary<NSString *, NSString *> *)info;

@end

NS_ASSUME_NONNULL_END

#endif
