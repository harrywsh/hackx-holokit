/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <Foundation/Foundation.h>
#import "UMCCommon.h"
#import "UMCLogListenerDelegate.h"

@protocol UMCEventsDelegate <NSObject>
@required

#pragma mark - Session

- (void) multipeerSessionPeer:(MCPeerID*)peerID didChangeState:(enum MCSessionState)state;
- (void) multipeerSessionStarted;
- (void) multipeerSessionDisconnected;

#pragma mark - Advertiser

- (void) multipeerAdvertiser:(MCNearbyServiceAdvertiser*)advertiser didReceiveInvitationFromPeer:(MCPeerID*)peerID
                 withContext:(NSData*)context
           invitationHandler:(void (^)(BOOL accept, MCSession* session))invitationHandler;

- (void) multipeerAdvertiser:(MCNearbyServiceAdvertiser*)advertiser didNotStartAdvertisingPeer:(NSError*)error;

#pragma mark - Advertiser assistant

- (void) multipeerAdvertiserAssistantWillPresentInvitation:(MCAdvertiserAssistant*)advertiserAssistant;

- (void) multipeerAdvertiserAssistantDidDismissInvitation:(MCAdvertiserAssistant*)advertiserAssistant;

#pragma mark - Custom peer discovery

- (void) multipeerNearbyServiceBrowser:(MCNearbyServiceBrowser*)browser foundPeer:(MCPeerID*)peerID withDiscoveryInfo:(NSDictionary<NSString*, NSString*>*)info;

- (void) multipeerNearbyServiceBrowser:(MCNearbyServiceBrowser*)browser lostPeer:(MCPeerID*)peerID;

- (void) multipeerNearbyServiceBrowser:(MCNearbyServiceBrowser*)browser didNotStartBrowsingForPeers:(NSError*)error;

#pragma mark - Peer discovery UI

- (void) multipeerBrowserViewControllerWasCancelled:(UMCBrowserViewController*)browserViewController;

- (void) multipeerBrowserViewControllerDidFinish:(UMCBrowserViewController*)browserViewController;

- (BOOL) multipeerBrowserViewController:(UMCBrowserViewController*)browserViewController
                shouldPresentNearbyPeer:(MCPeerID*)peerID
                      withDiscoveryInfo:(NSDictionary<NSString*, NSString*>*)info;

#pragma mark - Log

- (void)log:(const NSString*)text withLogType:(const enum UMCLogType)logType;

@end
