/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import "UMCLog.h"
#import "UMCConstants.h"
#import "UMCLogListenerDelegate.h"

static NSString* const LOG_TAG = @"MultipeerConnectivity";
static BOOL sIsStartupMessageLogged = NO;
static BOOL sIsVerbose = NO;

@implementation UMCLog {
}

static __weak id<UMCLogListenerDelegate> _delegate;

+ (id) delegate	{
    return _delegate;
}

+ (void) setDelegate:(id)delegate {
    _delegate = delegate;
}

+ (BOOL) isVerbose {
    return sIsVerbose;
}

+ (void) setIsVerbose:(BOOL)isVerbose {
    sIsVerbose = isVerbose;
}

+ (void) log:(const NSString*)text {
    [self logInternal:text withTitle:nil withLogType:UMCLogTypeLog];
}

+ (void) log:(const NSString*)text withTitle:(const NSString*)title {
    [self logInternal:text withTitle:title withLogType:UMCLogTypeLog];
}

+ (void) logWarning:(const NSString*)text {
    [self logInternal:text withTitle:nil withLogType:UMCLogTypeWarning];
}

+ (void) logWarning:(const NSString*)text withTitle:(const NSString*)title {
    [self logInternal:text withTitle:title withLogType:UMCLogTypeWarning];
}

+ (void) logError:(const NSString*)text{
    [self logInternal:text withTitle:nil withLogType:UMCLogTypeError];
}

+ (void) logError:(const NSString*)text withTitle:(const NSString*)title {
    [self logInternal:text withTitle:title withLogType:UMCLogTypeError];
}

+ (void) logStartupMessage {
    if (sIsStartupMessageLogged)
        return;

    sIsStartupMessageLogged = YES;
    NSLog(
            @"Starting %s v%s %s%s, built at %@",
            UMC_NAME,
            UMC_VERSION,
            UMC_BUILD_TYPE,
#if UMC_EVALUATION
            " evaluation",
#else
            "",
#endif
            [self getBuildDate]
    );
}

+ (void) logInternal:(const NSString*)text
           withTitle:(const NSString*)title
         withLogType:(const enum UMCLogType)logType {

    text = [self formatLog:text withTitle:title];

    NSString* logTypePrefix;
    switch(logType) {
        case UMCLogTypeLog:
            logTypePrefix =  @"";
            break;
        case UMCLogTypeWarning:
            logTypePrefix = @"{Warning} ";
            break;
        case UMCLogTypeError:
            logTypePrefix = @"{Error} ";
            break;
    }

    text = [NSString stringWithFormat:@"%@%@", logTypePrefix, text];
    if (_delegate != nil) {
        [_delegate log:text withLogType:logType];
    }

    text = [NSString stringWithFormat:@"[%@] %@", LOG_TAG, text];
    NSLog(@"%@", text);
}

+ (const NSString*) formatLog:(const NSString*)text
                    withTitle:(const NSString*)title {

    if (title != nil) {
        text = [NSString stringWithFormat:@"%@ - %@", title, text];
    } else {
        text = [NSString stringWithFormat:@"%@", text];
    }

    return text;
}

+ (NSString*) getBuildDate {
    NSString* buildDate;

    // Get build date and time, format to 'yyMMddHHmm'
    NSString* dateStr = [NSString stringWithFormat:@"%s %s", UMC_BUILD_DATE, UMC_BUILD_TIME];

    // Convert to date
    NSDateFormatter* dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"LLL d yyyy HH:mm:ss"];
    NSLocale* usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    [dateFormat setLocale:usLocale];
    NSDate* date = [dateFormat dateFromString:dateStr];

    // Set output format and convert to string
    [dateFormat setDateFormat:@"dd/MM/yyyy-HH:mm"];
    buildDate = [dateFormat stringFromDate:date];

    return buildDate;
}

@end
