/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <Foundation/Foundation.h>

#pragma clang diagnostic push
#pragma ide diagnostic ignored "OCUnusedGlobalDeclarationInspection"
#ifdef __cplusplus
extern "C" {
#endif

#pragma clang diagnostic push
#pragma ide diagnostic ignored "NotReleasedValue"
void UMC_NSObject_retain(NSObject* obj) {
    [obj retain];
}
#pragma clang diagnostic pop

void UMC_NSObject_release(NSObject* obj) {
    [obj release];
}

uint64_t UMC_NSObject_retainCount(NSObject* obj) {
    return (uint64_t) [obj retainCount];
}

#ifdef __cplusplus
}
#endif
#pragma clang diagnostic pop