/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <SystemConfiguration/SystemConfiguration.h>

#import <arpa/inet.h>
#import <netdb.h>

#import "UMCSocketsUtility.h"

@implementation UMCSocketsUtility {

}

#pragma mark Class IP and Host Utilities
// This IP Utilities are mostly inspired by or derived from Apple code. Thank you Apple.

+ (NSString*) stringFromAddress:(const struct sockaddr*)address {
    if (address && address->sa_family == AF_INET) {
        const struct sockaddr_in* sin = (struct sockaddr_in*) address;
        return [NSString stringWithFormat:@"%@:%d", [NSString stringWithUTF8String:inet_ntoa(sin->sin_addr)], ntohs(sin->sin_port)];
    }

    return nil;
}

+ (BOOL) addressFromString:(NSString*)IPAddress address:(struct sockaddr_in*)address {
    if (!IPAddress || ![IPAddress length]) return NO;

    memset((char*) address, sizeof(struct sockaddr_in), 0);
    address->sin_family = AF_INET;
    address->sin_len = sizeof(struct sockaddr_in);

    int conversionResult = inet_aton([IPAddress UTF8String], &address->sin_addr);
    if (conversionResult == 0) {
        NSAssert1(conversionResult != 1, @"Failed to convert the IP address string into a sockaddr_in: %@", IPAddress);
        return NO;
    }

    return YES;
}

+ (NSString*) addressFromData:(NSData*)addressData {
    NSString* adr = nil;

    if (addressData != nil) {
        struct sockaddr_in addrIn = *(struct sockaddr_in*) [addressData bytes];
        adr = [self addressFromSockAddr:&addrIn];
    }

    return adr;
}

+ (NSString*) addressFromSockAddr:(struct sockaddr_in*)address {
    NSString* adr = nil;

    if (address != NULL) {
        adr = [NSString stringWithFormat:@"%s", inet_ntoa((*address).sin_addr)];
    }

    return adr;
}

+ (int) portFromData:(NSData*)addressData {
    int port = -1;

    if (addressData != NULL) {
        struct sockaddr_in addrIn = *(struct sockaddr_in*) [addressData bytes];
        port = [self portFromSockAddr:&addrIn];
    }

    return port;
}

+ (int) portFromSockAddr:(struct sockaddr_in*)address {
    int port = -1;
    if (address != NULL) {
        port = ntohs((*address).sin_port);
    }

    return port;
}

+ (NSString*) hostname {
    char baseHostName[256]; // Thanks, Gunnar Larisch
    int success = gethostname(baseHostName, 255);
    if (success != 0) return nil;
    baseHostName[255] = '\0';

#if TARGET_IPHONE_SIMULATOR
    return [NSString stringWithFormat:@"%s", baseHostName];
#else
    return [NSString stringWithFormat:@"%s.local", baseHostName];
#endif
}

+ (NSString*) getIPAddressForHost:(NSString*)theHost {
    struct hostent* host = gethostbyname([theHost UTF8String]);
    if (!host) {
        herror("resolv");
        return NULL;
    }
    struct in_addr** list = (struct in_addr**) host->h_addr_list;
    NSString* addressString = [NSString stringWithCString:inet_ntoa(*list[0]) encoding:NSUTF8StringEncoding];
    return addressString;
}

+ (BOOL) sockAddrFromAddress:(NSString*)address andPort:(int)port outSocketAddress:(struct sockaddr_in*)sockAddr {
    memset(sockAddr, 0, sizeof(struct sockaddr_in));
    (*sockAddr).sin_family = AF_INET;
    (*sockAddr).sin_port = htons(port);

    // Load address.
    void* saddr = &((*sockAddr).sin_addr.s_addr);
    int result = inet_pton(AF_INET, [address UTF8String], saddr);
    return result == 1;
}

@end