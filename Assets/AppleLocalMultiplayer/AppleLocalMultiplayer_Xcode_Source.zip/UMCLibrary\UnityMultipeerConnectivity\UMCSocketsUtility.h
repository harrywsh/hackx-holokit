/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <Foundation/Foundation.h>

@interface UMCSocketsUtility : NSObject

+ (BOOL) sockAddrFromAddress:(NSString*)address andPort:(int)port outSocketAddress:(struct sockaddr_in*)sockAddr;

+ (NSString*) stringFromAddress:(const struct sockaddr*)address;

+ (BOOL) addressFromString:(NSString*)IPAddress address:(struct sockaddr_in*)address;

+ (NSString*) addressFromData:(NSData*)addressData;

+ (NSString*) addressFromSockAddr:(struct sockaddr_in*)address;

+ (int) portFromData:(NSData*)addressData;

+ (int) portFromSockAddr:(struct sockaddr_in*)address;

+ (NSString*) hostname;

+ (NSString*) getIPAddressForHost:(NSString*)theHost;
@end
