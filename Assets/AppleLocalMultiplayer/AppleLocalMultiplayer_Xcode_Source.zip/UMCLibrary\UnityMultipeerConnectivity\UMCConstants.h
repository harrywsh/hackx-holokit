/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

static const char* const UMC_VERSION = "1.0.0";
static const char* const UMC_NAME = "Unity Multipeer Connectivity";
static const char* const UMC_BUILD_DATE = __DATE__;
static const char* const UMC_BUILD_TIME = __TIME__;
static const char* const UMC_BUILD_TYPE =
#ifdef DEBUG
    "debug"
#else
    "release"
#endif
;