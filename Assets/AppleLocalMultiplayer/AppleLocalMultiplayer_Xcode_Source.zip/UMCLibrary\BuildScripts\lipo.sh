#!/bin/sh -e
set -euo pipefail

# define output folder environment variable
UNIVERSAL_OUTPUT_FOLDER_NAME=${CONFIGURATION}-${UMC_UNIVERSAL_NAME}-universal
UNIVERSAL_OUTPUT_FOLDER=${BUILD_DIR}/${UNIVERSAL_OUTPUT_FOLDER_NAME}

# Step 1. Build Device and Simulator versions
xcodebuild -scheme "${UMC_SCHEME_NAME}" -workspace "${PROJECT_FILE_PATH}/project.xcworkspace" ONLY_ACTIVE_ARCH=NO -configuration ${CONFIGURATION} -sdk ${UMC_DEVICE_SDK_NAME} UMC_EVALUATION=${UMC_EVALUATION}
xcodebuild -scheme "${UMC_SCHEME_NAME}" -workspace "${PROJECT_FILE_PATH}/project.xcworkspace" ONLY_ACTIVE_ARCH=NO -configuration ${CONFIGURATION} -sdk ${UMC_SIMULATOR_SDK_NAME} VALID_ARCHS="i386 x86_64" UMC_EVALUATION=${UMC_EVALUATION}

# make sure the output directory exists
mkdir -p "${UNIVERSAL_OUTPUT_FOLDER}"

# Step 2. Create universal binary file using lipo
lipo -create -output "${UNIVERSAL_OUTPUT_FOLDER}/lib${UMC_LIBRARY_NAME}.a" "${BUILD_DIR}/${CONFIGURATION}-${UMC_DEVICE_SDK_NAME}/lib${UMC_LIBRARY_NAME}.a" "${BUILD_DIR}/${CONFIGURATION}-${UMC_SIMULATOR_SDK_NAME}/lib${UMC_LIBRARY_NAME}.a"

mkdir -p "Artifacts"
rm -rf "Artifacts/${UNIVERSAL_OUTPUT_FOLDER_NAME}"
cp -R "${UNIVERSAL_OUTPUT_FOLDER}" "Artifacts/${UNIVERSAL_OUTPUT_FOLDER_NAME}"

# Last touch. copy the header files. Just for convenience
# cp -R "${BUILD_DIR}/${CONFIGURATION}-${DEVICE_SDK_NAME}/include" "${UNIVERSAL_OUTPUT_FOLDER}/"