/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#define UMC_MALLOC_ARRAY(count, type) (count == 0 ? NULL : (type*) malloc(count * sizeof(type)))

typedef struct UMC_StringStringKeyValuePair {
    const char* key;
    const char* value;
} UMC_StringStringKeyValuePair;

#ifdef __cplusplus
extern "C" {
#endif

bool UMC_ConvertDictionaryToStringStringPairs(NSDictionary<NSString*, NSString*>* dictionary, UMC_StringStringKeyValuePair** outPairArray, int* outPairCount);

NSDictionary<NSString*, NSString*>* UMC_ConvertStringStringPairsToDictionary(UMC_StringStringKeyValuePair* pairs, int32_t pairCount);

void UMC_FreeStringStringKeyValuePairs(UMC_StringStringKeyValuePair* pairs, int32_t pairCount);

#ifdef __cplusplus
}
#endif