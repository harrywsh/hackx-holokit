/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import "UMCCommon.h"
#import "UMCAdvertiserAssistant.h"
#import "UMCPeerDiscoveryDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface UMCPeerDiscovery : NSObject

@property (weak, nullable) id<UMCPeerDiscoveryDelegate> delegate;

#if !TARGET_OS_OSX
- (instancetype) initWithSessionContainer:(UMCSessionContainer*)sessionContainer andViewController:(UIViewController*)viewController;
#elif TARGET_OS_OSX
- (instancetype) initWithSessionContainer:(UMCSessionContainer*)sessionContainer andMainWindow:(NSWindow*)mainWindow;
#endif

- (BOOL) startDiscovery:(NSError* __autoreleasing *)error;

- (BOOL) stopDiscovery:(NSError* __autoreleasing *)error;

- (BOOL) invitePeer:(MCPeerID*)peerID withTimeout:(NSTimeInterval)timeout error:(NSError* __autoreleasing *)error;


- (BOOL) openPeerBrowserWithMinimumNumberOfPeers:(NSUInteger)minimumNumberOfPeers
                         andMaximumNumberOfPeers:(NSUInteger)maximumNumberOfPeers
                                           error:(NSError* __autoreleasing *)error;

- (BOOL) closePeerBrowser:(NSError* __autoreleasing *)error;

@end

NS_ASSUME_NONNULL_END
