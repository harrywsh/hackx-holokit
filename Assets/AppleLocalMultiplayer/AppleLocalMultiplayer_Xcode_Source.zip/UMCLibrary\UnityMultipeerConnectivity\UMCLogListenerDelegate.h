/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import "UMCCommon.h"

@protocol UMCLogListenerDelegate <NSObject>
@required

- (void)log:(const NSString*)text withLogType:(const enum UMCLogType)logType;

@end