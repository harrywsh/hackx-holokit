/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <Foundation/Foundation.h>
#import "UMCPeerState.h"
#import "UMCSessionContainer.h"
#import "UMCSettings.h"
#import "UMCSessionControllerDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface UMCSessionController : NSObject {
    @protected
    id<UMCSessionControllerDelegate> __weak _delegate;
    NSMutableArray<UMCPeerState*>* _peers;
    UMCSessionContainer* _sessionContainer;
}

@property (weak, nullable) id<UMCSessionControllerDelegate> delegate;
@property (nonatomic, strong, readonly) NSMutableArray<UMCPeerState*>* peers;
@property (nonatomic, strong) UMCSessionContainer* sessionContainer;
- (instancetype) initWithDisplayName:(NSString*)displayName
                      andServiceType:(NSString*)serviceType;

- (void) peerBrowserFoundPeer:(MCPeerID*)peerID withDiscoveryInfo:(NSDictionary<NSString*, NSString*>*)info;

- (void) peerBrowserLostPeer:(MCPeerID*)peerID;
@end

NS_ASSUME_NONNULL_END
