/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <MultipeerConnectivity/MultipeerConnectivity.h>
#import "UMCMultipeerConnectivityUtility.h"


@implementation UMCMultipeerConnectivityUtility {

}

// Helper method for human readable printing of MCSessionState.
+ (NSString*) stringForPeerConnectionState:(MCSessionState)state
{
    switch (state) {
        case MCSessionStateConnected:
            return @"Connected";

        case MCSessionStateConnecting:
            return @"Connecting";

        case MCSessionStateNotConnected:
            return @"Not Connected";
    }

    return @"Unknown";
}

@end