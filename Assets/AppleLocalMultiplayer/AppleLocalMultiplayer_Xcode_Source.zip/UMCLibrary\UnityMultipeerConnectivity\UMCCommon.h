/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <MultipeerConnectivity/MultipeerConnectivity.h>
#import "UMCLog.h"
#import "UMCErrors.h"
#import "MCBrowserViewControllerSurrogate.h"

#if TARGET_OS_OSX
  #if 0
    #define UMCBrowserViewController MCBrowserViewController
    #define UMCBrowserViewControllerDelegate MCBrowserViewControllerDelegate
  #else
    #define UMCBrowserViewController MCBrowserViewControllerSurrogate
    #define UMCBrowserViewControllerDelegate MCBrowserViewControllerSurrogateDelegate
  #endif
#else
  #define UMCBrowserViewController MCBrowserViewController
  #define UMCBrowserViewControllerDelegate MCBrowserViewControllerDelegate
#endif
