/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import "UMCCommon.h"
#import "UMCAdvertiser.h"

static NSString* const LOG_TAG = @"Advertiser";

@interface UMCAdvertiser () <MCNearbyServiceAdvertiserDelegate>
@end

@implementation UMCAdvertiser {
    MCNearbyServiceAdvertiser* _advertiser;
}

- (void) dealloc {
    UMC_LOG_VERBOSE(@"dealloc");

    NSError *__autoreleasing error;
    [self stopAdvertising:&error];
}

- (BOOL) startAdvertisingWithSessionContainer:(UMCSessionContainer*)sessionContainer
                             andDiscoveryInfo:(NSDictionary*)discoveryInfo
                                        error:(NSError* __autoreleasing *)error {
    if (_isAdvertising) {
        *error = UMC_NSERROR(UMCErrorInvalidState, @"Advertiser is already advertising");
        return NO;
    }

    UMC_LOG(@"Start advertising");

    // Create the advertiser assistant for managing incoming invitation
    _advertiser = [[MCNearbyServiceAdvertiser alloc] initWithPeer:sessionContainer.session.myPeerID
                                                    discoveryInfo:discoveryInfo
                                                      serviceType:sessionContainer.serviceType];
    _advertiser.delegate = self;

    // Start the assistant to begin advertising your peer availability
    [_advertiser startAdvertisingPeer];
    _isAdvertising = YES;
    return YES;
}

- (BOOL) stopAdvertising:(NSError* __autoreleasing *)error {
    if (!_isAdvertising) {
        *error = UMC_NSERROR(UMCErrorInvalidState, @"Advertiser was not advertising");
        return NO;
    }

    UMC_LOG(@"Stop advertising");

    if (_advertiser != nil) {
        [_advertiser stopAdvertisingPeer];
        _advertiser.delegate = nil;
    }
    _isAdvertising = NO;
    return YES;
}

#pragma mark - MCNearbyServiceAdvertiserDelegate

- (void)              advertiser:(MCNearbyServiceAdvertiser*)advertiser
    didReceiveInvitationFromPeer:(MCPeerID*)peerID
                     withContext:(NSData*)context
               invitationHandler:(void (^)(BOOL accept, MCSession* session))invitationHandler {
    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    if (_delegate == nil)
        return;

    [_delegate advertiser:advertiser didReceiveInvitationFromPeer:peerID withContext:context invitationHandler:invitationHandler];
}

- (void) advertiser:(MCNearbyServiceAdvertiser*)advertiser didNotStartAdvertisingPeer:(NSError*)error {
    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    if (_delegate == nil)
        return;

    [_delegate advertiser:advertiser didNotStartAdvertisingPeer:error];
}

@end
