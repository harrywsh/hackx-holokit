/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <Foundation/Foundation.h>
#import <MultipeerConnectivity/MultipeerConnectivity.h>

#import "UMCSessionContainerDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface UMCSessionContainer : NSObject

@property (weak, nullable) id<UMCSessionContainerDelegate> delegate;
@property (readonly, nonatomic) MCSession* session;
@property (readonly, nonatomic) NSString* displayName;
@property (readonly, nonatomic) NSString* serviceType;

- (instancetype) initWithDisplayName:(NSString*)displayName andServiceType:(NSString*)serviceType;
@end

NS_ASSUME_NONNULL_END
