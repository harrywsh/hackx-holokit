/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <Foundation/Foundation.h>
#import "UMCEventsDelegate.h"
#import "UMCUnityBridgeUtilities.h"
#import "UMCLogListenerDelegate.h"

#pragma mark - Event data structs

struct UMC_ErrorStringEventData {
    const char* error;
};

struct UMC_PeerFoundEventData {
    /* MCPeerID* */ void* peerID;
    UMC_StringStringKeyValuePair* discoveryInfoPairArray;
    int32_t discoveryInfoArrayPairCount;
};

#pragma mark - Session

typedef struct UMC_SessionPeerStateChangedEventData {
    /* MCSession* */ void* peerID;
    int32_t newPeerState;
} UMC_SessionPeerStateChangedEventData;

#pragma mark - Advertiser

typedef struct UMC_AdvertiserInvitationReceivedEventData {
    /* MCPeerID* */ void* peerID;
    /* UMCAdvertiserInvitationHandlerBlock */ void* invitationHandler;
} UMC_AdvertiserInvitationReceivedEventData;

typedef struct UMC_ErrorStringEventData UMC_AdvertiserStartFailedEventData;

#pragma mark - Custom peer discovery

typedef struct UMC_PeerFoundEventData UMC_NearbyServiceBrowserPeerFoundEventData;

typedef struct UMC_NearbyServiceBrowserPeerLostEventData {
    void* peerID;
} UMC_NearbyServiceBrowserPeerLostEventData;

typedef struct UMC_ErrorStringEventData UMC_NearbyServiceBrowserStartFailedEventData;

#pragma mark - Peer discovery UI

typedef struct UMC_BrowserViewControllerNearbyPeerPresentingResultEventData {
    bool shouldPresent;
} UMC_BrowserViewControllerNearbyPeerPresentingResultEventData;

typedef struct UMC_BrowserViewControllerNearbyPeerPresentingEventData {
    /* MCPeerID* */ void* peerID;
    UMC_StringStringKeyValuePair* discoveryInfoPairArray;
    int32_t discoveryInfoArrayPairCount;

    UMC_BrowserViewControllerNearbyPeerPresentingResultEventData* result;
} UMC_BrowserViewControllerNearbyPeerPresentingEventData;

#pragma mark - Logs
typedef struct UMC_LogEventData {
    enum UMCLogType type;
    const char* text;
} UMC_LogEventData;

typedef NS_ENUM(int32_t, UMCUnityEventType) {
    // Session
    UMCUnityEventTypeSessionStarted,
    UMCUnityEventTypeSessionDisconnected,
    UMCUnityEventTypeSessionPeerStateChanged,

    // Advertiser
    UMCUnityEventTypeAdvertiserInvitationReceived,
    UMCUnityEventTypeAdvertiserStartFailed,

    // Advertiser assistant
    UMCUnityEventTypeAdvertiserAssistantInvitationDismissed,
    UMCUnityEventTypeAdvertiserAssistantInvitationPresenting,

    // Custom peer discovery
    UMCUnityEventTypeNearbyServiceBrowserPeerFound,
    UMCUnityEventTypeNearbyServiceBrowserPeerLost,
    UMCUnityEventTypeNearbyServiceBrowserStartFailed,

    // Peer discovery UI
    UMCUnityEventTypeBrowserViewControllerCancelled,
    UMCUnityEventTypeBrowserViewControllerFinished,
    UMCUnityEventTypeBrowserViewControllerNearbyPeerPresenting,

    // Logs
    UMCUnityEventTypeLog
};

typedef void (*UMCUnityEventHandlerFunc)(UMCUnityEventType message, void* eventData);

typedef void (^UMCAdvertiserInvitationHandlerBlock)(BOOL accept, MCSession* session);

@interface UMCUnityEvents : NSObject<UMCEventsDelegate>

+ (UMCUnityEvents*) sharedInstance;

@property () UMCUnityEventHandlerFunc eventHandlerFunc;

@end