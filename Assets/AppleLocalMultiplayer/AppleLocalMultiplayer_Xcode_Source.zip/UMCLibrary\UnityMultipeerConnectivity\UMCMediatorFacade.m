/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <CoreBluetooth/CoreBluetooth.h>

#import "UMCCommon.h"
#import "UMCMediatorFacade.h"
#import "UMCAdvertiser.h"
#import "UMCUnityEvents.h"
#import "UMCLogListenerDelegate.h"

#if UMC_EVALUATION
  #import "UMCEvaluationManager.h"
  #define CHECK_EVALUATION() [[UMCEvaluationManager sharedInstance] checkEvaluation]
#else
  #define CHECK_EVALUATION()
#endif

static NSString* const LOG_TAG = @"MediatorFacade";

@interface UMCMediatorFacade () <
    UMCPeerDiscoveryDelegate,
    MCAdvertiserAssistantDelegate,
    MCNearbyServiceAdvertiserDelegate,
    UMCSessionControllerDelegate,
    UMCLogListenerDelegate>
@end

@implementation UMCMediatorFacade {
    UMCSettings* _settings;
    CBCentralManager* _bluetoothManager;
    UMCAdvertiserAssistant* _advertiserAssistant;
    UMCAdvertiser* _advertiser;
}

+ (UMCMediatorFacade*) sharedInstance {
    static UMCMediatorFacade* sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
    });
    return sharedInstance;
}

- (instancetype) init {
    self = [super init];
    if (self) {
        [UMCLog logStartupMessage];

        _isSessionActive = NO;
        _settings = [UMCSettings new];
        _bluetoothManager =
            [[CBCentralManager alloc]
                initWithDelegate:nil
                           queue:nil
                         options:@{CBCentralManagerOptionShowPowerAlertKey : @0}];
        _advertiserAssistant = [UMCAdvertiserAssistant new];
        _advertiserAssistant.delegate = self;

        _advertiser = [UMCAdvertiser new];
        _advertiser.delegate = self;
    }

    return self;
}

- (void) dealloc {
    NSError* error;
    [self disconnectFromSession:&error];
}

- (void) setLogForwarding:(BOOL)logForwarding {
    UMCLog.delegate = (logForwarding ? self : nil);
}

- (BOOL) setDstHost:(NSString*)dstHost andDstPort:(int)dstPort error:(NSError* __autoreleasing *)error {
    CHECK_EVALUATION();
    _settings.remoteHost = dstHost;
    _settings.remoteHostPort = (unsigned short) dstPort;
    return YES;
}

- (BOOL) setServiceType:(NSString*)serviceType error:(NSError* __autoreleasing *)error {
    CHECK_EVALUATION();
    BOOL isValid = [UMCMediatorFacade isValidServiceType:serviceType error:error];
    if (!isValid) {
        UMC_LOG_ERROR((*error).localizedDescription);
        return NO;
    }

    _settings.serviceType = serviceType;
    return YES;
}

- (BOOL) setDisplayName:(NSString*)displayName error:(NSError* __autoreleasing *)error {
    CHECK_EVALUATION();
    BOOL isValid = [UMCMediatorFacade isValidPeerDisplayName:displayName error:error];
    if (!isValid) {
        UMC_LOG_ERROR((*error).localizedDescription);
        return NO;
    }

    _settings.displayName = displayName;
    return YES;
}

#if !TARGET_OS_OSX
- (BOOL) setViewController:(UIViewController*)viewController error:(NSError* __autoreleasing *)error; {
    CHECK_EVALUATION();
    if (_isSessionActive) {
        *error = UMC_NSERROR(UMCErrorSessionActive, @"Session must not be active when setting the View Controller");
        return NO;
    }

    _settings.viewController = viewController;
    return YES;
}
#elif TARGET_OS_OSX
- (BOOL) setMainWindow:(NSWindow*)mainWindow error:(NSError* __autoreleasing *)error {
    CHECK_EVALUATION();
    if (_isSessionActive) {
        *error = UMC_NSERROR(UMCErrorSessionActive, @"Session must not be active when setting the main window");
        return NO;
    }

    _settings.mainWindow = mainWindow;
    return YES;
}
#endif

- (BOOL) startSession:(NSError* __autoreleasing *)error; {
    CHECK_EVALUATION();
    if (_isSessionActive) {
        *error = UMC_NSERROR(UMCErrorSessionActive, @"Session is already active");
        return NO;
    }

    if (_settings.remoteHost == nil || _settings.remoteHost.length == 0) {
        *error = UMC_NSERROR(UMCErrorInvalidState, @"Remote host can not be empty");
        UMC_LOG_ERROR((*error).localizedDescription);
        return NO;
    }

    if (_settings.remoteHostPort <= 0) {
        *error = UMC_NSERROR(UMCErrorInvalidState, @"Remote host port is <= 0");
        UMC_LOG_ERROR((*error).localizedDescription);
        return NO;
    }

    BOOL isValid;

    isValid = [UMCMediatorFacade isValidServiceType:_settings.serviceType error:error];
    if (!isValid) {
        UMC_LOG_ERROR((*error).localizedDescription);
        return NO;
    }

    isValid = [UMCMediatorFacade isValidPeerDisplayName:_settings.displayName error:error];
    if (!isValid) {
        UMC_LOG_ERROR((*error).localizedDescription);
        return NO;
    }

    UMC_LOG_VERBOSE(@"Starting session");
    NSError __autoreleasing * errorTmp;
    [_advertiser stopAdvertising:&errorTmp];
    [_advertiserAssistant stopAdvertising:&errorTmp];
    _sessionController = [[UMCUdpNetworkingSessionController alloc] initWithDisplayName:_settings.displayName
                                                                         andServiceType:_settings.serviceType
                                                                             andDstHost:_settings.remoteHost
                                                                         andDstHostPort:_settings.remoteHostPort];
    _sessionController.delegate = self;
#if !TARGET_OS_OSX
    _peerDiscovery = [[UMCPeerDiscovery alloc] initWithSessionContainer:_sessionController.sessionContainer
                                                      andViewController:_settings.viewController];
#elif TARGET_OS_OSX
    _peerDiscovery = [[UMCPeerDiscovery alloc] initWithSessionContainer:_sessionController.sessionContainer
                                                          andMainWindow:_settings.mainWindow];
#endif

    _peerDiscovery.delegate = self;

    _isSessionActive = YES;
    [[UMCUnityEvents sharedInstance] multipeerSessionStarted];

    return YES;
}

- (BOOL) disconnectFromSession:(NSError* __autoreleasing *)error {
    CHECK_EVALUATION();
    if (!_isSessionActive) {
        *error = UMC_NSERROR_SESSION_NOT_ACTIVE();
        return NO;
    }

    UMC_LOG_VERBOSE(@"Stopping session");

    [_sessionController.sessionContainer.session disconnect];
    _sessionController = nil;

    NSError __autoreleasing * errorTmp;
    [self stopPeerDiscovery:&errorTmp];
    [self stopAdvertiserAssistant:&errorTmp];
    [self stopAdvertiser:&errorTmp];

    [[UMCUnityEvents sharedInstance] multipeerSessionDisconnected];

    _isSessionActive = NO;
    return YES;
}

- (NSArray*) getConnectedPeers:(NSError* __autoreleasing *)error; {
    CHECK_EVALUATION();
    if (!_isSessionActive) {
        *error = UMC_NSERROR_SESSION_NOT_ACTIVE();
        return nil;
    }

    return _sessionController.sessionContainer.session.connectedPeers;
}

#if !(TARGET_OS_OSX || TARGET_OS_TV)

- (BOOL) isBluetoothEnabled {
    CHECK_EVALUATION();
    return _bluetoothManager.state == CBCentralManagerStatePoweredOn;
}

- (BOOL) openBluetoothEnablePrompt:(NSError* __autoreleasing *)error; {
    CHECK_EVALUATION();
#if !TARGET_OS_SIMULATOR
    if (self.isBluetoothEnabled) {
        *error = UMC_NSERROR(UMCErrorInvalidState, @"Bluetooth is already enabled");
        return NO;
    }

    CBCentralManager* cbCentralManager =
        [[CBCentralManager alloc]
        initWithDelegate:nil
                   queue:nil
                 options:@{CBCentralManagerOptionShowPowerAlertKey : @(YES)}];

    return cbCentralManager != nil;
#else
    *error = UMC_NSERROR(UMCErrorNotSupported, @"Not supported on simulator");
    return NO;
#endif
}

#endif

#pragma mark - Advertiser assistant

- (BOOL) startAdvertiserAssistantWithDiscoveryInfo:(NSDictionary<NSString*, NSString*>*)discoveryInfo
                                             error:(NSError* __autoreleasing *)error {
    CHECK_EVALUATION();
    if (!_isSessionActive) {
        *error = UMC_NSERROR_SESSION_NOT_ACTIVE();
        return NO;
    }

    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    return
            [_advertiserAssistant
                    startAdvertisingWithSessionContainer:_sessionController.sessionContainer
                                        andDiscoveryInfo:discoveryInfo
                                                   error:error];
}

- (BOOL) stopAdvertiserAssistant:(NSError* __autoreleasing *)error {
    CHECK_EVALUATION();
    if (!_isSessionActive) {
        *error = UMC_NSERROR_SESSION_NOT_ACTIVE();
        return NO;
    }

    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    return [_advertiserAssistant stopAdvertising:error];
}

- (BOOL) isAdvertiserAssistantAdvertising {
    CHECK_EVALUATION();
    if (!_isSessionActive)
        return NO;

    return _advertiserAssistant.isAdvertising;
}

#pragma mark - Advertiser

- (BOOL) startAdvertiserWithDiscoveryInfo:(NSDictionary<NSString*, NSString*>*)
        discoveryInfo error:(NSError* __autoreleasing *)error {
    CHECK_EVALUATION();
    if (!_isSessionActive) {
        *error = UMC_NSERROR_SESSION_NOT_ACTIVE();
        return NO;
    }

    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    return [_advertiser startAdvertisingWithSessionContainer:_sessionController.sessionContainer
                                            andDiscoveryInfo:discoveryInfo
                                                       error:error];
}

- (BOOL) stopAdvertiser:(NSError* __autoreleasing *)error; {
    CHECK_EVALUATION();
    if (!_isSessionActive) {
        *error = UMC_NSERROR_SESSION_NOT_ACTIVE();
        return NO;
    }

    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    return [_advertiser stopAdvertising:error];
}

- (BOOL) isAdvertiserAdvertising {
    CHECK_EVALUATION();
    if (!_isSessionActive)
        return NO;

    return _advertiser.isAdvertising;
}

#pragma mark - Custom peer discovery

- (BOOL) startPeerDiscovery:(NSError* __autoreleasing *)error {
    CHECK_EVALUATION();
    if (!_isSessionActive) {
        *error = UMC_NSERROR_SESSION_NOT_ACTIVE();
        return NO;
    }

    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    return [_peerDiscovery startDiscovery:error];
}

- (BOOL) stopPeerDiscovery:(NSError* __autoreleasing *)error {
    CHECK_EVALUATION();
    if (!_isSessionActive) {
        *error = UMC_NSERROR_SESSION_NOT_ACTIVE();
        return NO;
    }

    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    return [_peerDiscovery stopDiscovery:error];
}

- (BOOL) invitePeerToSession:(MCPeerID*)peerID withTimeout:(NSTimeInterval)timeout error:(NSError* __autoreleasing *)error {
    CHECK_EVALUATION();
    if (!_isSessionActive) {
        *error = UMC_NSERROR_SESSION_NOT_ACTIVE();
        return NO;
    }

    UMC_LOG_VERBOSE([NSString stringWithFormat:@"Inviting peer %@", peerID.displayName]);
    return [_peerDiscovery invitePeer:peerID withTimeout:timeout error:error];
}

#pragma mark - Peer discovery UI

- (BOOL) openPeerBrowserWithMinimumNumberOfPeers:(NSUInteger)minimumNumberOfPeers
                         andMaximumNumberOfPeers:(NSUInteger)maximumNumberOfPeers
                                           error:(NSError* __autoreleasing *)error {
    CHECK_EVALUATION();
    if (!_isSessionActive) {
        *error = UMC_NSERROR_SESSION_NOT_ACTIVE();
        return NO;
    }

    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    [_peerDiscovery openPeerBrowserWithMinimumNumberOfPeers:minimumNumberOfPeers
                                    andMaximumNumberOfPeers:maximumNumberOfPeers
                                                      error:error];
    return YES;
}

- (BOOL) closePeerBrowser:(NSError* __autoreleasing *)error {
    CHECK_EVALUATION();
    if (!_isSessionActive) {
        *error = UMC_NSERROR_SESSION_NOT_ACTIVE();
        return NO;
    }

    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    [_peerDiscovery closePeerBrowser:error];
    return YES;
}

#pragma mark - UMCSessionControllerDelegate

- (void) session:(MCSession*)session peer:(MCPeerID*)peerID didChangeState:(enum MCSessionState)state {
    [[UMCUnityEvents sharedInstance] multipeerSessionPeer:peerID didChangeState:state];
}

#pragma mark - MCAdvertiserAssistantDelegate

- (void) advertiserAssistantWillPresentInvitation:(MCAdvertiserAssistant*)advertiserAssistant {
    [[UMCUnityEvents sharedInstance] multipeerAdvertiserAssistantWillPresentInvitation:advertiserAssistant];
}

- (void) advertiserAssistantDidDismissInvitation:(MCAdvertiserAssistant*)advertiserAssistant {
    [[UMCUnityEvents sharedInstance] multipeerAdvertiserAssistantDidDismissInvitation:advertiserAssistant];
}

#pragma mark - MCNearbyServiceAdvertiserDelegate

- (void) advertiser:(MCNearbyServiceAdvertiser*)advertiser
    didReceiveInvitationFromPeer:(MCPeerID*)peerID
    withContext:(NSData*)context
    invitationHandler:(void (^)(BOOL accept, MCSession* session))invitationHandler {
    [[UMCUnityEvents sharedInstance] multipeerAdvertiser:advertiser
                            didReceiveInvitationFromPeer:peerID
                                             withContext:context
                                       invitationHandler:invitationHandler];
}

- (void) advertiser:(MCNearbyServiceAdvertiser*)advertiser didNotStartAdvertisingPeer:(NSError*)error {
    [[UMCUnityEvents sharedInstance] multipeerAdvertiser:advertiser didNotStartAdvertisingPeer:error];
}

#pragma mark - UMCPeerDiscoveryDelegate

- (void) browser:(MCNearbyServiceBrowser*)browser foundPeer:(MCPeerID*)peerID withDiscoveryInfo:(NSDictionary*)info {
    [_sessionController peerBrowserFoundPeer:peerID withDiscoveryInfo:info];
    [[UMCUnityEvents sharedInstance] multipeerNearbyServiceBrowser:browser foundPeer:peerID withDiscoveryInfo:info];
}

- (void) browser:(MCNearbyServiceBrowser*)browser lostPeer:(MCPeerID*)peerID {
    [_sessionController peerBrowserLostPeer:peerID];
    [[UMCUnityEvents sharedInstance] multipeerNearbyServiceBrowser:browser lostPeer:peerID];
}

- (void) browser:(MCNearbyServiceBrowser*)browser didNotStartBrowsingForPeers:(NSError*)error {
    [[UMCUnityEvents sharedInstance] multipeerNearbyServiceBrowser:browser didNotStartBrowsingForPeers:error];
}

#pragma mark - MCBrowserViewControllerDelegate

- (void) browserViewControllerDidFinish:(UMCBrowserViewController*)browserViewController {
    NSError* __autoreleasing error = nil;
    [_peerDiscovery closePeerBrowser:&error];
    if (error != nil) {
        UMC_LOG_ERROR_VERBOSE(error.localizedDescription);
    }

    [[UMCUnityEvents sharedInstance] multipeerBrowserViewControllerDidFinish:browserViewController];
}

- (void) browserViewControllerWasCancelled:(UMCBrowserViewController*)browserViewController {
    NSError* __autoreleasing error = nil;
    [_peerDiscovery closePeerBrowser:&error];
    if (error != nil) {
        UMC_LOG_ERROR_VERBOSE(error.localizedDescription);
    }

    [[UMCUnityEvents sharedInstance] multipeerBrowserViewControllerWasCancelled:browserViewController];
}

- (BOOL) browserViewController:(UMCBrowserViewController*)browserViewController
       shouldPresentNearbyPeer:(MCPeerID*)peerID
             withDiscoveryInfo:(NSDictionary<NSString*, NSString*>*)info {
    [_sessionController peerBrowserFoundPeer:peerID withDiscoveryInfo:info];

    return [[UMCUnityEvents sharedInstance] multipeerBrowserViewController:browserViewController
                                                   shouldPresentNearbyPeer:peerID
                                                         withDiscoveryInfo:info];
}

#pragma mark - UMCLogListenerDelegate

- (void)log:(const NSString*)text withLogType:(const enum UMCLogType)logType {
    [[UMCUnityEvents sharedInstance] log:text withLogType:logType];
}

#pragma mark - Helpers

+ (BOOL) isValidPeerDisplayName:(NSString*)displayName error:(NSError* __autoreleasing *)error {
    if (displayName == nil || displayName.length == 0) {
        *error = UMC_NSERROR(UMCErrorInvalidInput, @"Peer display name can not be empty");
        return NO;
    }

    NSUInteger bytes = [displayName lengthOfBytesUsingEncoding:NSUTF8StringEncoding];
    if (bytes > 63) {
        *error = UMC_NSERROR(UMCErrorInvalidInput, @"Peer display name must not be longer than 63 bytes in UTF8 encoding");
        return NO;
    }
    return YES;
}

+ (BOOL) isValidServiceType:(NSString*)serviceType error:(NSError* __autoreleasing *)error {
    if (serviceType == nil || serviceType.length == 0) {
        *error = UMC_NSERROR(UMCErrorInvalidInput, @"Service type can not be empty");
        return NO;
    }

    static NSRegularExpression* regex;
    if (regex == nil) {
        NSError* regexError;
        regex = [[NSRegularExpression alloc] initWithPattern:@"^[a-z\\-\\d]{1,15}$" options:0 error:&regexError];
        if (regexError != nil) {
            NSString* errorText = [NSString stringWithFormat:@"Service type validation error: %@", [regexError localizedDescription]];
            *error = UMC_NSERROR(UMCErrorInvalidInput, errorText);
            return NO;
        }
    }

    BOOL isMatch = [regex firstMatchInString:serviceType options:0 range:NSMakeRange(0, serviceType.length)] != nil;
    if (!isMatch) {
        *error =
                UMC_NSERROR(
                        UMCErrorInvalidInput,
                        @"Service type must be up to 15 characters long and can only "
                                "include ASCII lowercase letters, numbers, and hyphen.");
    }
    return isMatch;
}

@end

