/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <Foundation/Foundation.h>
#import "UMCLog.h"

static NSString* const UMC_NSERROR_DOMAIN = @"com.lostpolygon.unitymultipeerconnectivity";
static NSString* const UMC_NSERROR_INVALID_INPUT_KEY = @"UMCInvalidInputName";

typedef NS_ENUM(int32_t, UMCErrorType) {
    UMCErrorNone,
    UMCErrorFatal,
    UMCErrorNotSupported,
    UMCErrorSessionActive,
    UMCErrorSessionNotActive,
    UMCErrorInvalidState,
    UMCErrorInvalidInput
};

#define UMC_NSERROR(__code, __message) \
[NSError errorWithDomain:UMC_NSERROR_DOMAIN \
                    code:__code \
                userInfo:@{ \
                              NSLocalizedDescriptionKey: __message \
                        }]

#define UMC_NSERROR_SESSION_NOT_ACTIVE() UMC_NSERROR(UMCErrorSessionNotActive, @"Session was not active")

#define UMC_NSERROR_INVALID_INPUT(__message, __inputName) \
[NSError errorWithDomain:UMC_NSERROR_DOMAIN \
                    code:UMCErrorInvalidInput \
                userInfo:@{ \
                              NSLocalizedDescriptionKey: __message, \
                              UMC_NSERROR_INVALID_INPUT_KEY: __inputName \
                        }]
