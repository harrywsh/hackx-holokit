/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <MultipeerConnectivity/MultipeerConnectivity.h>
#import "UMCCommon.h"
#import "UMCAdvertiserAssistant.h"
#import "UMCSessionContainer.h"

static NSString* const LOG_TAG = @"AdvertiserAssistant";

@interface UMCAdvertiserAssistant () <MCAdvertiserAssistantDelegate>
@end

@implementation UMCAdvertiserAssistant {
    MCAdvertiserAssistant* _advertiserAssistant;
}

- (void) dealloc {
    UMC_LOG_VERBOSE(@"dealloc");

    NSError *__autoreleasing error;
    [self stopAdvertising:&error];
}

- (BOOL) startAdvertisingWithSessionContainer:(UMCSessionContainer*)sessionContainer
                             andDiscoveryInfo:(NSDictionary*)discoveryInfo
                                        error:(NSError* __autoreleasing *)error {
    if (_isAdvertising) {
        *error = UMC_NSERROR(UMCErrorInvalidState, @"Advertiser is already advertising");
        return NO;
    }

    UMC_LOG(@"Start advertising");

    // Create the advertiser assistant for managing incoming invitation
    _advertiserAssistant = [[MCAdvertiserAssistant alloc] initWithServiceType:sessionContainer.serviceType
                                                                discoveryInfo:discoveryInfo
                                                                      session:sessionContainer.session];
    _advertiserAssistant.delegate = self;

    // Start the assistant to begin advertising your peer availability
    [_advertiserAssistant start];
    _isAdvertising = YES;
    return YES;
}

- (BOOL) stopAdvertising:(NSError* __autoreleasing *)error {
    if (!_isAdvertising) {
        *error = UMC_NSERROR(UMCErrorInvalidState, @"Advertiser was not advertising");
        return NO;
    }

    UMC_LOG(@"Stop advertising");

    if (_advertiserAssistant != nil) {
        [_advertiserAssistant stop];
        _advertiserAssistant.delegate = nil;
    }
    _isAdvertising = NO;
    return YES;
}

#pragma mark - MCAdvertiserAssistantDelegate

- (void) advertiserAssistantWillPresentInvitation:(MCAdvertiserAssistant*)advertiserAssistant {
    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    if (_delegate == nil)
        return;

    [_delegate advertiserAssistantWillPresentInvitation:advertiserAssistant];
}

- (void) advertiserAssistantDidDismissInvitation:(MCAdvertiserAssistant*)advertiserAssistant {
    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    if (_delegate == nil)
        return;

    [_delegate advertiserAssistantDidDismissInvitation:advertiserAssistant];
}


@end
