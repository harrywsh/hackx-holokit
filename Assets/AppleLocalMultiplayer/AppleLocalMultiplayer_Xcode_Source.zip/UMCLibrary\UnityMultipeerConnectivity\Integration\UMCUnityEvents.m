/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import "UMCUnityEvents.h"
#import "UMCUnityBridge.h"
#import "UMCLogListenerDelegate.h"

#define UMC_MALLOC_STRUCT_NODECL(type, name) name = (type*) malloc(sizeof(type))
#define UMC_MALLOC_STRUCT(type, name) type* UMC_MALLOC_STRUCT_NODECL(type, name)

static NSString* const LOG_TAG = @"UnityEvents";

@implementation UMCUnityEvents {

}

+ (UMCUnityEvents*) sharedInstance {
    static UMCUnityEvents* sharedMyInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedMyInstance = [[self alloc] init];
    });
    return sharedMyInstance;
}

#pragma mark - Session

- (void) multipeerSessionPeer:(MCPeerID*)peerID didChangeState:(enum MCSessionState)state {
    if (_eventHandlerFunc == NULL)
        return;

    UMC_MALLOC_STRUCT(UMC_SessionPeerStateChangedEventData, eventData);
    eventData->peerID = (__bridge_retained void*) peerID;
    eventData->newPeerState = (int32_t) state;

    _eventHandlerFunc(UMCUnityEventTypeSessionPeerStateChanged, eventData);
}

- (void) multipeerSessionStarted {
    if (_eventHandlerFunc == NULL)
        return;

    _eventHandlerFunc(UMCUnityEventTypeSessionStarted, NULL);
}

- (void) multipeerSessionDisconnected {
    if (_eventHandlerFunc == NULL)
        return;

    _eventHandlerFunc(UMCUnityEventTypeSessionDisconnected, NULL);
}

#pragma mark - Advertiser

- (void) multipeerAdvertiser: (MCNearbyServiceAdvertiser*)advertiser didReceiveInvitationFromPeer:(MCPeerID*)peerID withContext:(NSData*)context invitationHandler:(void (^)(BOOL accept, MCSession* session))invitationHandler {
    if (_eventHandlerFunc == NULL) {
        UMC_LOG_ERROR(@"_eventHandlerFunc == NULL");
        return;
    }

    UMC_MALLOC_STRUCT(UMC_AdvertiserInvitationReceivedEventData, eventData);
    eventData->peerID = (__bridge_retained void*) peerID;
    eventData->invitationHandler = (__bridge_retained void*) invitationHandler;

    _eventHandlerFunc(UMCUnityEventTypeAdvertiserInvitationReceived, eventData);
}

- (void) multipeerAdvertiser:(MCNearbyServiceAdvertiser*)advertiser didNotStartAdvertisingPeer:(NSError*)error {
    if (_eventHandlerFunc == NULL)
        return;

    UMC_MALLOC_STRUCT(UMC_AdvertiserStartFailedEventData, eventData);
    eventData->error = strdup([error.localizedDescription UTF8String]);

    _eventHandlerFunc(UMCUnityEventTypeAdvertiserStartFailed, eventData);
}

#pragma mark - Advertiser assistant

- (void) multipeerAdvertiserAssistantWillPresentInvitation:(MCAdvertiserAssistant*)advertiserAssistant {
    if (_eventHandlerFunc == NULL)
        return;

    _eventHandlerFunc(UMCUnityEventTypeAdvertiserAssistantInvitationPresenting, NULL);
}

- (void) multipeerAdvertiserAssistantDidDismissInvitation:(MCAdvertiserAssistant*)advertiserAssistant {
    if (_eventHandlerFunc == NULL)
        return;

    _eventHandlerFunc(UMCUnityEventTypeAdvertiserAssistantInvitationDismissed, NULL);
}

#pragma mark - Custom peer discovery

- (void) multipeerNearbyServiceBrowser:(MCNearbyServiceBrowser*)browser foundPeer:(MCPeerID*)peerID withDiscoveryInfo:(NSDictionary<NSString*, NSString*>*)info {
    if (_eventHandlerFunc == NULL)
        return;

    UMC_MALLOC_STRUCT(UMC_NearbyServiceBrowserPeerFoundEventData, eventData);
    eventData->peerID = (__bridge_retained void*) peerID;
    UMC_ConvertDictionaryToStringStringPairs(info, &eventData->discoveryInfoPairArray, &eventData->discoveryInfoArrayPairCount);

    _eventHandlerFunc(UMCUnityEventTypeNearbyServiceBrowserPeerFound, eventData);
}

- (void) multipeerNearbyServiceBrowser:(MCNearbyServiceBrowser*)browser lostPeer:(MCPeerID*)peerID {
    if (_eventHandlerFunc == NULL)
        return;

    UMC_MALLOC_STRUCT(UMC_NearbyServiceBrowserPeerLostEventData, eventData);
    eventData->peerID = (__bridge_retained void*) peerID;

    _eventHandlerFunc(UMCUnityEventTypeNearbyServiceBrowserPeerLost, eventData);
}

- (void) multipeerNearbyServiceBrowser:(MCNearbyServiceBrowser*)browser didNotStartBrowsingForPeers:(NSError*)error {
    if (_eventHandlerFunc == NULL)
        return;

    UMC_MALLOC_STRUCT(UMC_NearbyServiceBrowserStartFailedEventData, eventData);
    eventData->error = strdup([error.localizedDescription UTF8String]);

    _eventHandlerFunc(UMCUnityEventTypeNearbyServiceBrowserStartFailed, eventData);
}

#pragma mark - Peer discovery UI

- (void) multipeerBrowserViewControllerWasCancelled:(UMCBrowserViewController*)browserViewController {
    if (_eventHandlerFunc == NULL)
        return;

    _eventHandlerFunc(UMCUnityEventTypeBrowserViewControllerCancelled, NULL);
}

- (void) multipeerBrowserViewControllerDidFinish:(UMCBrowserViewController*)browserViewController {
    if (_eventHandlerFunc == NULL)
        return;

    _eventHandlerFunc(UMCUnityEventTypeBrowserViewControllerFinished, NULL);
}

- (BOOL) multipeerBrowserViewController:(UMCBrowserViewController*)browserViewController
                shouldPresentNearbyPeer:(MCPeerID*)peerID
                      withDiscoveryInfo:(NSDictionary<NSString*, NSString*>*)info {
    if (_eventHandlerFunc == NULL)
        return YES;

    UMC_MALLOC_STRUCT(UMC_BrowserViewControllerNearbyPeerPresentingEventData, eventData);
    eventData->peerID = (__bridge_retained void*) peerID;
    UMC_ConvertDictionaryToStringStringPairs(info, &eventData->discoveryInfoPairArray, &eventData->discoveryInfoArrayPairCount);
    UMC_MALLOC_STRUCT_NODECL(UMC_BrowserViewControllerNearbyPeerPresentingResultEventData, eventData->result);

    _eventHandlerFunc(UMCUnityEventTypeBrowserViewControllerNearbyPeerPresenting, eventData);
    BOOL shouldPresent = eventData->result->shouldPresent;
    UMC_FreeEventData(UMCUnityEventTypeBrowserViewControllerNearbyPeerPresenting, eventData);
    return shouldPresent;
}

#pragma mark - Logs

- (void)log:(const NSString*)text withLogType:(const enum UMCLogType)logType {
    if (_eventHandlerFunc == NULL)
        return;

    UMC_MALLOC_STRUCT(UMC_LogEventData, eventData);
    eventData->type = logType;
    eventData->text = strdup([text UTF8String]);

    _eventHandlerFunc(UMCUnityEventTypeLog, eventData);
}


@end
