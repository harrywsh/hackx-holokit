/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <Foundation/Foundation.h>
#import "UMCSessionContainer.h"
#import "UMCPeerState.h"
#import "UMCSettings.h"
#import "UMCSessionController.h"

@interface UMCUdpNetworkingSessionController : UMCSessionController

- (instancetype) initWithDisplayName:(NSString*)displayName
                      andServiceType:(NSString*)serviceType
                          andDstHost:(NSString*) dstHost
                      andDstHostPort:(unsigned short) dstHostPort;

@end