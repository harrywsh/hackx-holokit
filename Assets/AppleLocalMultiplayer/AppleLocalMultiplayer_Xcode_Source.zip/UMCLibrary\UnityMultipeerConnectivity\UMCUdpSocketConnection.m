/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <arpa/inet.h>
#import <net/if.h>
#import <dlfcn.h>
#import <notify.h>

#import "UMCUdpSocketConnection.h"
#import "UMCUdpSocketConnectionDelegate.h"
#import "UMCLog.h"
#import "UMCSocketsUtility.h"

static NSString* const LOG_TAG = @"UDP";

@implementation UMCUdpSocketConnection {
    NSData* _dstAddress;
    UMCGCDAsyncUdpSocket* _socket;
    dispatch_queue_t _delegateQueue;
}

- (instancetype) initWithDstHost:(NSString*)dstHost
                         dstPort:(int)dstPort
                         srcPort:(int)srcPort
                   delegateQueue:(dispatch_queue_t)delegateQueue
                        delegate:(id<UMCUdpSocketConnectionDelegate>)delegate {
    self = [super init];
    if (self) {
        UMC_LOG_VERBOSE([NSString stringWithFormat:@"init: dstHost: %@, dstPort: %d, srcPort: %d", dstHost, dstPort, srcPort]);

        _dstHost = dstHost;
        _dstPort = dstPort;
        _srcPort = srcPort;
        _delegateQueue = delegateQueue;
        _delegate = delegate;
    }

    return self;
}

- (void) setDstPort:(int)port {
    if (_dstPort == port)
        return;
    
    _dstPort = port;

    [self updateDstAddress];
}

- (void) startSocket {
    [self stopConnection:NO];

    @try {
        _socket = [[UMCGCDAsyncUdpSocket alloc] initWithDelegate:self delegateQueue:_delegateQueue];
        [_socket setPreferIPv4];
        [_socket setIPv6Enabled:NO];

        NSError* error;
        [_socket bindToPort:(uint16_t) _srcPort error:&error];
        if (error != nil) {
            @throw [NSException exceptionWithName:@"SocketException" reason:error.localizedDescription userInfo:nil];
        }

        if (_srcPort == 0) {
            _srcPort = [_socket localPort_IPv4];
        }
        
        [self updateDstAddress];
        
        [_socket setMaxReceiveIPv4BufferSize:65000];
        [_socket beginReceiving:&error];
        if (error != NULL) {
            @throw [NSException exceptionWithName:@"SocketException" reason:error.localizedDescription userInfo:nil];
        }
        
        UMC_LOG_VERBOSE([NSString stringWithFormat:@"start: dstHost: %@, dstPort: %d, srcPort: %d", _dstHost, _dstPort, _srcPort]);

        _isDisconnected = NO;
        _isRunning = YES;
    } @catch (NSException* e) {
        UMC_LOG_ERROR([NSString stringWithFormat:@"Error while starting: %@", e]);
        [self stopConnection:YES];
    }
}

- (BOOL) send:(NSData*)data withTimeout:(NSTimeInterval)timeout {
    if (!_isRunning || _isDisconnecting)
        return NO;

    @try {
        [_socket sendData:data toAddress:_dstAddress withTimeout:timeout tag:0];
    } @catch (NSException* e) {
        [self stopConnection:YES];

        UMC_LOG_ERROR([NSString stringWithFormat:@"Error while sending: %@", e]);
        return NO;
    }

    return YES;
}

- (void) stopConnection {
    [self stopConnection:NO];
}

- (void) stopConnection:(BOOL)notifyDelegate {
    UMC_LOG_VERBOSE([NSString stringWithFormat:@"stopConnection: %@", notifyDelegate ? @"delegate notified" : @"not notifying"]);

    _isDisconnecting = true;
    if (_socket != nil) {
        _socket.delegate = nil;
        if (!_socket.isClosed) {
            [_socket close];
        }
    }

    _socket = nil;
    _isRunning = false;
    _isDisconnecting = false;
    _isDisconnected = true;

    if (notifyDelegate && _delegate != nil) {
        [_delegate udpSocketFailure:self];
    }
}

- (void)updateDstAddress {
    struct sockaddr_in addr;
    BOOL result = [UMCSocketsUtility sockAddrFromAddress:_dstHost andPort:_dstPort outSocketAddress:&addr];
    if (!result) {
        UMC_LOG_ERROR(@"Error in [UMCSocketsUtility sockAddressFromAddress]");
        return;
    }

    _dstAddress = [[NSData alloc] initWithBytes:&addr length:sizeof(struct sockaddr_in)];
}

#pragma mark - UMCGCDAsyncUdpSocketDelegate

- (void) udpSocket:(UMCGCDAsyncUdpSocket*)sock didConnectToAddress:(NSData*)address {

}

- (void) udpSocket:(UMCGCDAsyncUdpSocket*)sock didNotConnect:(NSError*)error {

}

- (void) udpSocket:(UMCGCDAsyncUdpSocket*)sock didSendDataWithTag:(long)tag {

}

- (void) udpSocket:(UMCGCDAsyncUdpSocket*)sock didNotSendDataWithTag:(long)tag dueToError:(NSError*)error {
    if (error != nil) {
        UMC_LOG_ERROR([NSString stringWithFormat:@"didNotSendDataWithTag:dueToError - %@", error]);
    }

    [self stopConnection:YES];
}

- (void) udpSocket:(UMCGCDAsyncUdpSocket*)sock didReceiveData:(NSData*)data fromAddress:(NSData*)address withFilterContext:(id)filterContext {
    [_delegate udpSocketRead:self fromAddress:address withData:data];
}

- (void) udpSocketDidClose:(UMCGCDAsyncUdpSocket*)sock withError:(NSError*)error {
    if (error != nil) {
        UMC_LOG_ERROR([NSString stringWithFormat:@"udpSocketDidClose:withError - %@", error]);
    }

    [self stopConnection:YES];
}

@end