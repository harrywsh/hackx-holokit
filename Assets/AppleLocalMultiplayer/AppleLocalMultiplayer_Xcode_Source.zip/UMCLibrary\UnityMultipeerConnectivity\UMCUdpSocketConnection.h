/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <Foundation/Foundation.h>
#import "UMCGCDAsyncUdpSocket.h"

NS_ASSUME_NONNULL_BEGIN

@protocol UMCUdpSocketConnectionDelegate;

@interface UMCUdpSocketConnection : NSObject<UMCGCDAsyncUdpSocketDelegate>

@property (weak, nullable) id<UMCUdpSocketConnectionDelegate> delegate;

@property(readonly, nonatomic) BOOL isRunning;
@property(readonly, nonatomic) BOOL isDisconnecting;
@property(readonly, nonatomic) BOOL isDisconnected;

@property(readonly, nonatomic, copy) NSString* dstHost;
@property(nonatomic) int dstPort;
@property(readonly, nonatomic) int srcPort;

- (instancetype) initWithDstHost:(NSString*)dstHost
                         dstPort:(int)dstPort
                         srcPort:(int)srcPort
                   delegateQueue:(dispatch_queue_t)delegateQueue
                        delegate:(id<UMCUdpSocketConnectionDelegate>)delegate;

- (void) setDstPort:(int)port;

- (void) startSocket;

- (BOOL) send:(NSData*)data withTimeout:(NSTimeInterval)timeout;

- (void) stopConnection;
@end

NS_ASSUME_NONNULL_END