/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <MultipeerConnectivity/MultipeerConnectivity.h>
#import "UMCCommon.h"
#import "UMCSessionContainer.h"
#import "UMCCachedPeerIDContainer.h"

static NSString* const LOG_TAG = @"SessionContainer";

@interface UMCSessionContainer () <MCSessionDelegate>
@end

@implementation UMCSessionContainer {

}

- (instancetype) initWithDisplayName:(NSString*)displayName andServiceType:(NSString*)serviceType {
    UMC_LOG([NSString stringWithFormat:@"initWithDisplayName:%@ andServiceType:%@", displayName, serviceType]);

    if (self = [self init]) {
        _displayName = displayName;
        _serviceType = serviceType;

        // Create the peerID ID with user input display name.  This display name will be seen by other browsing peers
        MCPeerID* peerID = [[UMCCachedPeerIDContainer sharedInstance] getPeerIDWithDisplayName:_displayName];
        // Create the session that peers will be invited/join into.  You can provide an optinal security identity for custom authentication.  Also you can set the encryption preference for the session.
        _session = [[MCSession alloc] initWithPeer:peerID securityIdentity:nil encryptionPreference:MCEncryptionNone];
        // Set ourselves as the MCSessionDelegate
        _session.delegate = self;
    }

    return self;
}

// On dealloc we should clean up the session by disconnecting from it.
- (void) dealloc {
    UMC_LOG(@"dealloc");

    [_session disconnect];
}

#pragma mark - MCSessionDelegate

- (void) session:(MCSession*)session peer:(MCPeerID*)peerID didChangeState:(MCSessionState)state {
    if (_delegate == nil)
        return;

    [_delegate session:session peer:peerID didChangeState:state];
}

- (void) session:(MCSession*)session didReceiveData:(NSData*)data fromPeer:(MCPeerID*)peerID {
    if (_delegate == nil)
        return;

    [_delegate session:session didReceiveData:data fromPeer:peerID];
}

- (void) session:(MCSession*)session didReceiveStream:(NSInputStream*)stream withName:(NSString*)streamName fromPeer:(MCPeerID*)peerID {
    // Not used
}

- (void) session:(MCSession*)session didStartReceivingResourceWithName:(NSString*)resourceName fromPeer:(MCPeerID*)peerID withProgress:(NSProgress*)progress {
    // Not used
}

- (void) session:(MCSession*)session didFinishReceivingResourceWithName:(NSString*)resourceName fromPeer:(MCPeerID*)peerID atURL:(NSURL*)localURL withError:(NSError*)error {
    // Not used
}

- (void) session:(MCSession*)session didReceiveCertificate:(NSArray*)certificate fromPeer:(MCPeerID*)peerID certificateHandler:(void (^)(BOOL accept))certificateHandler {
    if (certificateHandler != nil) {
        certificateHandler(YES);
    }
}

@end

