/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <Foundation/Foundation.h>
#import "UMCUdpSocketConnection.h"

@protocol UMCUdpSocketConnectionDelegate <NSObject>
- (void) udpSocketRead:(UMCUdpSocketConnection*)socketConnection fromAddress:(NSData*)address withData:(NSData*)data;
- (void) udpSocketFailure:(UMCUdpSocketConnection*)socketConnection;
@end
