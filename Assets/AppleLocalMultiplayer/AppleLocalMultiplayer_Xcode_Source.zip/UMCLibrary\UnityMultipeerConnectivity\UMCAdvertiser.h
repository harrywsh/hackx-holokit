/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import "UMCCommon.h"
#import "UMCSessionContainer.h"

NS_ASSUME_NONNULL_BEGIN

@interface UMCAdvertiser : NSObject

@property (readonly, nonatomic) BOOL isAdvertising;

@property (weak, nullable) id<MCNearbyServiceAdvertiserDelegate> delegate;

- (BOOL) startAdvertisingWithSessionContainer:(UMCSessionContainer*)sessionContainer
                             andDiscoveryInfo:(NSDictionary*)discoveryInfo
                                        error:(NSError* __autoreleasing *)error;

- (BOOL) stopAdvertising:(NSError* __autoreleasing *)error;

@end

NS_ASSUME_NONNULL_END