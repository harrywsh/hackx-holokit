/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <Foundation/Foundation.h>
#include "UMCUnityBridgeUtilities.h"

#ifdef __cplusplus
extern "C" {
#endif

bool UMC_ConvertDictionaryToStringStringPairs(NSDictionary<NSString*, NSString*>* dictionary, UMC_StringStringKeyValuePair** outPairArray, int* outPairCount) {
    *outPairArray = NULL;
    *outPairCount = 0;
    if (dictionary == nil)
        return false;

    int pairCount = (int) dictionary.count;
    UMC_StringStringKeyValuePair* pairArray = UMC_MALLOC_ARRAY(pairCount, UMC_StringStringKeyValuePair);

    int counter = 0;
    for (NSString* key in dictionary) {
        NSString* value = dictionary[key];

        UMC_StringStringKeyValuePair pair;
        pair.key = strdup([key UTF8String]);
        pair.value = strdup([value UTF8String]);

        pairArray[counter] = pair;
        counter++;
    }

    *outPairArray = pairArray;
    *outPairCount = pairCount;

    return true;
}

NSDictionary<NSString*, NSString*>* UMC_ConvertStringStringPairsToDictionary(UMC_StringStringKeyValuePair* pairs, int32_t pairCount) {
    if (pairs == NULL)
        return nil;

    NSMutableDictionary<NSString*, NSString*>* dict = [[NSMutableDictionary alloc] initWithCapacity:(NSUInteger) pairCount];
    for (int i = 0; i < pairCount; ++i) {
        NSString* key = [NSString stringWithUTF8String:pairs[i].key];
        NSString* value = [NSString stringWithUTF8String:pairs[i].value];

        dict[key] = value;
    }

    return dict;
}

void UMC_FreeStringStringKeyValuePairs(UMC_StringStringKeyValuePair* pairs, int32_t pairCount) {
    for (int i = 0; i < pairCount; ++i) {
        free((void*) pairs[i].key);
        free((void*) pairs[i].value);
    }

    free((void*) pairs);
}

#ifdef __cplusplus
}
#endif