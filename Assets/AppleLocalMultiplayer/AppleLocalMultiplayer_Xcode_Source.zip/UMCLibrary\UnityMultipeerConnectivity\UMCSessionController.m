/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import "UMCSessionController.h"
#import "UMCSessionController.Protected.h"
#import "UMCLog.h"
#import "UMCMultipeerConnectivityUtility.h"

static NSString* const LOG_TAG = @"SessionController";

@implementation UMCSessionController {

}

@synthesize peers = _peers;
@synthesize sessionContainer = _sessionContainer;

- (instancetype) initWithDisplayName:(NSString*)displayName andServiceType:(NSString*)serviceType {
    if (self = [super init]) {
        _peers = [NSMutableArray new];
        _sessionContainer = [[UMCSessionContainer alloc] initWithDisplayName:displayName andServiceType:serviceType];
        _sessionContainer.delegate = self;
    }

    return self;
}

- (void) peerBrowserFoundPeer:(MCPeerID*)peerID withDiscoveryInfo:(NSDictionary<NSString*, NSString*>*)info {
    UMCPeerState* peerState = [self getPeerStateByPeerID:peerID andCreateIfMissing:NO];
    if (peerState != nil) {
        peerState.lastDiscoveryInfo = info;
    }
}

- (void) peerBrowserLostPeer:(MCPeerID*)peerID {

}

#pragma mark - UMCSessionContainerDelegate

- (void) session:(MCSession*)session peer:(MCPeerID*)peerID didChangeState:(enum MCSessionState)state {
    UMC_LOG_VERBOSE([NSString stringWithFormat:@"peerID:%@ didChangeState:%@", peerID.displayName, [UMCMultipeerConnectivityUtility stringForPeerConnectionState:state]]);

    UMCPeerState* peerState = [self getPeerStateByPeerID:peerID andCreateIfMissing:YES];
    peerState.state = state;
    [self processPeerStateChange:peerID newPeerState:peerState];

    if (_delegate != nil) {
        [_delegate session:session peer:peerID didChangeState:state];
    }
}

- (void) session:(MCSession*)session didReceiveData:(NSData*)data fromPeer:(MCPeerID*)peerID {
    //UMC_LOG_VERBOSE([NSString stringWithFormat:@"received %lu bytes from %@", (unsigned long) data.length, peerID.displayName]);
}

- (UMCPeerState*) getPeerStateByPeerID:(MCPeerID*)peerID andCreateIfMissing:(BOOL)isCreateIfMissing {
    UMCPeerState* peerState = nil;
    for (UMCPeerState* peerStateTmp in _peers) {
        if (peerStateTmp.peerID == peerID) {
            peerState = peerStateTmp;
            break;
        }
    }

    if (peerState == nil && isCreateIfMissing) {
        peerState = [self createPeerStateForPeer:peerID];
        [_peers addObject:peerState];
    }

    return peerState;
}

@end