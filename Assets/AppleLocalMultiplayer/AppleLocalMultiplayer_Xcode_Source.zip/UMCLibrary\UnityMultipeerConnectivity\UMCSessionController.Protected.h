/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <objc/NSObject.h>
#import "UMCPeerState.h"
#import "UMCSessionController.h"

@protocol UMCSessionControllerProtectedMethods <NSObject, UMCSessionContainerDelegate>

- (void) processPeerStateChange:(MCPeerID*)peerID newPeerState:(UMCPeerState*)peerState;

- (UMCPeerState*) createPeerStateForPeer:(MCPeerID*)peerID;

- (UMCPeerState*) getPeerStateByPeerID:(MCPeerID*)peerID andCreateIfMissing:(BOOL)isCreateIfMissing;

@end

@interface UMCSessionController (ProtectedMethods) <UMCSessionControllerProtectedMethods>
@end