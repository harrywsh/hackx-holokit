/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <Foundation/Foundation.h>

#ifdef __cplusplus
extern "C" {
#endif

void UMC_NSObject_retain(NSObject* obj);

void UMC_NSObject_release(NSObject* obj);

#ifdef __cplusplus
}
#endif