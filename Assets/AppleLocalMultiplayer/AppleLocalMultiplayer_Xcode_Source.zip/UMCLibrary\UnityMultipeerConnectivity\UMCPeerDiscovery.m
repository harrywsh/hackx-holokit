/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import "UMCCommon.h"
#import "UMCPeerDiscovery.h"
#import "UMCSessionContainer.h"

static NSString* const LOG_TAG = @"PeerDiscovery";

@interface UMCPeerDiscovery () <UMCBrowserViewControllerDelegate, MCNearbyServiceBrowserDelegate>
@end

@implementation UMCPeerDiscovery {
    UMCSessionContainer* _sessionContainer;
    MCNearbyServiceBrowser* _nearbyServiceBrowser;
    UMCBrowserViewController* _browserViewController;
#if !TARGET_OS_OSX
    UIViewController* _viewController;
#elif TARGET_OS_OSX
    __weak NSWindow* _mainWindow;
    NSWindow* _browserViewControllerWindow;
#endif
}

#if !TARGET_OS_OSX
- (instancetype) initWithSessionContainer:(UMCSessionContainer*)sessionContainer andViewController:(UIViewController*)viewController {
    if (self = [super init]) {
        _sessionContainer = sessionContainer;
        _viewController = viewController;
    }

    return self;
}
#elif TARGET_OS_OSX
- (instancetype) initWithSessionContainer:(UMCSessionContainer*)sessionContainer andMainWindow:(NSWindow*)mainWindow {
    if (self = [super init]) {
        _sessionContainer = sessionContainer;
        _mainWindow = mainWindow;
    }

    return self;
}
#endif

- (BOOL) startDiscovery:(NSError* __autoreleasing *)error {
    if (_nearbyServiceBrowser != nil) {
        *error = UMC_NSERROR(UMCErrorInvalidState, @"Service discovery is already started");
        return NO;
    }

    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    [self createServiceBrowser];
    [_nearbyServiceBrowser startBrowsingForPeers];
    return YES;
}

- (BOOL) stopDiscovery:(NSError* __autoreleasing *)error {
    if (_nearbyServiceBrowser == nil) {
        *error = UMC_NSERROR(UMCErrorInvalidState, @"Service discovery was not started");
        return NO;
    }

    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    [self closePeerBrowser:error];
    [_nearbyServiceBrowser stopBrowsingForPeers];
    _nearbyServiceBrowser.delegate = nil;
    _nearbyServiceBrowser = nil;

    return YES;
}

- (BOOL) openPeerBrowserWithMinimumNumberOfPeers:(NSUInteger)minimumNumberOfPeers
                         andMaximumNumberOfPeers:(NSUInteger)maximumNumberOfPeers
                                           error:(NSError* __autoreleasing *)error {
    if (_browserViewController != nil) {
        *error = UMC_NSERROR(UMCErrorInvalidState, @"Service browser is already open");
        return NO;
    }

#if !TARGET_OS_OSX
    if (_viewController == nil) {
        *error = UMC_NSERROR(UMCErrorInvalidState, @"viewController == nil");
        return NO;
    }
#elif TARGET_OS_OSX
    if (_mainWindow == nil) {
        *error = UMC_NSERROR(UMCErrorInvalidState, @"mainWindow == nil");
        return NO;
    }
#endif

    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    if (_nearbyServiceBrowser == nil) {
        [self createServiceBrowser];
    }

    _nearbyServiceBrowser.delegate = nil;
    _browserViewController = [[UMCBrowserViewController alloc] initWithBrowser:_nearbyServiceBrowser
                                                                      session:_sessionContainer.session];
    _browserViewController.delegate = self;
    _browserViewController.minimumNumberOfPeers = minimumNumberOfPeers;
    _browserViewController.maximumNumberOfPeers = maximumNumberOfPeers;

#if !TARGET_OS_OSX
    [_viewController presentViewController:_browserViewController animated:YES completion:nil];
#elif TARGET_OS_OSX
    _browserViewControllerWindow = [NSWindow windowWithContentViewController:_browserViewController];
    [_mainWindow beginSheet:_browserViewControllerWindow completionHandler:nil];
#endif

    return YES;
}

- (BOOL) closePeerBrowser:(NSError* __autoreleasing *)error {
    if (_browserViewController == nil) {
        *error = UMC_NSERROR(UMCErrorInvalidState, @"Service browser was not opened");
        return NO;
    }

    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    if (_nearbyServiceBrowser != nil) {
        _nearbyServiceBrowser.delegate = self;
    }

#if !TARGET_OS_OSX
    [_browserViewController dismissViewControllerAnimated:YES completion:nil];
#elif TARGET_OS_OSX
    [_mainWindow endSheet:_browserViewControllerWindow];
    _browserViewControllerWindow = nil;
#endif
    
    _browserViewController = nil;
    [_nearbyServiceBrowser stopBrowsingForPeers];
    _nearbyServiceBrowser.delegate = nil;
    _nearbyServiceBrowser = nil;

    return YES;
}

- (BOOL) invitePeer:(MCPeerID*)peerID withTimeout:(NSTimeInterval)timeout error:(NSError* __autoreleasing *)error {
    if (_nearbyServiceBrowser == nil) {
        *error = UMC_NSERROR(UMCErrorInvalidState, @"Service discovery was not started");
        return NO;
    }

    [_nearbyServiceBrowser invitePeer:peerID toSession:_sessionContainer.session withContext:nil timeout:timeout];
    return YES;
}

- (void) createServiceBrowser {
    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    _nearbyServiceBrowser = [[MCNearbyServiceBrowser alloc] initWithPeer:_sessionContainer.session.myPeerID
                                                             serviceType:_sessionContainer.serviceType];
    _nearbyServiceBrowser.delegate = self;
}

#pragma mark - MCNearbyServiceBrowserDelegate

// Found a nearby advertising peer.
- (void)        browser:(MCNearbyServiceBrowser*)browser
              foundPeer:(MCPeerID*)peerID
      withDiscoveryInfo:(nullable NSDictionary<NSString*, NSString*>*)info{
    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    if (_delegate == nil)
        return;

    [_delegate browser:browser foundPeer:peerID withDiscoveryInfo:info];
}

// A nearby peer has stopped advertising.
- (void) browser:(MCNearbyServiceBrowser*)browser lostPeer:(MCPeerID*)peerID {
    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    if (_delegate == nil)
        return;

    [_delegate browser:browser lostPeer:peerID];
}

// Browsing did not start due to an error.
- (void) browser:(MCNearbyServiceBrowser*)browser didNotStartBrowsingForPeers:(NSError *)error{
    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    if (_delegate == nil)
        return;

    [_delegate browser:browser didNotStartBrowsingForPeers:error];
}

#pragma mark - MCBrowserViewControllerDelegate

- (void) browserViewControllerDidFinish:(UMCBrowserViewController*)browserViewController {
    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    if (_delegate != nil) {
        [_delegate browserViewControllerDidFinish:browserViewController];
    }

    _browserViewController = nil;
}

- (void) browserViewControllerWasCancelled:(UMCBrowserViewController*)browserViewController {
    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    if (_delegate != nil) {
        [_delegate browserViewControllerWasCancelled:browserViewController];
    }

    _browserViewController = nil;
}

- (BOOL) browserViewController:(UMCBrowserViewController*)browserViewController
       shouldPresentNearbyPeer:(MCPeerID*)peerID
             withDiscoveryInfo:(NSDictionary<NSString*, NSString*>*)info {
    UMC_LOG_VERBOSE(UMC_LOG_PRETTY_FUNCTION);
    if (_delegate == nil)
        return YES;

    return [_delegate browserViewController:browserViewController
                    shouldPresentNearbyPeer:peerID
                          withDiscoveryInfo:info];
}

@end
