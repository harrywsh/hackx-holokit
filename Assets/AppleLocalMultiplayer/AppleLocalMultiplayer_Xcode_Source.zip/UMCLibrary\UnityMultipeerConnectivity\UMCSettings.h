/*
 * Copyright (c) 2017, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

#import <Foundation/Foundation.h>
#import "UMCCommon.h"

@interface UMCSettings : NSObject {

}

@property (nonatomic, copy) NSString* serviceType;
@property (nonatomic, copy) NSString* displayName;
@property (nonatomic, retain) NSString* remoteHost;
@property (nonatomic, assign) unsigned short remoteHostPort;
#if !TARGET_OS_OSX
@property (weak) UIViewController* viewController;
#elif TARGET_OS_OSX
@property (weak) NSWindow* mainWindow;
#endif

@end
